/**
 * Compliance Inputs Section - v4
 * Structured, editable compliance inputs that feed documents and the Technical Dossier.
 *
 * Inputs include:
 * - Vessel Identity & General Description
 * - Vessel Systems (existing)
 * - Applied Standards (existing)
 * - Declarations & Ratings (CE related)
 * - Technical References (index, not files)
 *
 * Rules:
 * - Inputs are editable structured data, not PDFs
 * - Inputs may link to evidence in the Technical Dossier
 * - Inputs are reusable across multiple documents
 */

'use client';

import { useState } from 'react';
import {
  Anchor,
  BookOpen,
  ClipboardList,
  Edit,
  FileText,
  Info,
  Layers,
  Plus,
  Settings2,
  Ship,
  Check,
  X,
  AlertCircle,
  Download,
  RefreshCw,
} from 'lucide-react';
import type {
  Project,
  VesselIdentity,
  VesselIdentityInit,
  ComplianceDeclarations,
} from '@/domain/models';
import { ProjectRepository } from '@/data/repositories';
import { ProjectService } from '@/domain/services/ProjectService';
import { BoatModelService, type BoatModel } from '@/domain/services/BoatModelService';
import { useAuth, PermissionGuard } from '@/v4/state/useAuth';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  getFieldDossierEvidence,
} from '@/domain/utils/information-linking';
import { DossierSectionHint } from './SourceHint';
// NOTE: AI suggestions are NOT available for vessel identity fields
// AI is restricted to text-authoring surfaces (Owner's Manual sections, compliance snippets)

// ============================================
// TYPES
// ============================================

interface ComplianceInputsSectionProps {
  project: Project;
  onRefresh: () => void;
}

// ============================================
// HELPERS
// ============================================

function getVesselIdentityCompleteness(identity?: VesselIdentity): { complete: number; total: number } {
  if (!identity) return { complete: 0, total: 8 };

  const fields = [
    identity.modelName,
    identity.win,
    identity.builderName,
    identity.designCategory,
    identity.maxPersons,
    identity.loaMeters,
    identity.yearOfConstruction,
    identity.intendedUse,
  ];

  const complete = fields.filter((f) => f !== undefined && f !== '').length;
  return { complete, total: 8 };
}

function getDeclarationsCompleteness(declarations?: ComplianceDeclarations): { complete: number; total: number } {
  if (!declarations) return { complete: 0, total: 5 };

  const fields = [
    declarations.docReferenceNumber,
    declarations.docIssueDate,
    declarations.docSignatory,
    declarations.conformityModule,
    declarations.docSignatoryRole,
  ];

  const complete = fields.filter((f) => f !== undefined && f !== '').length;
  return { complete, total: 5 };
}

// ============================================
// MAIN COMPONENT
// ============================================

export function ComplianceInputsSection({ project, onRefresh }: ComplianceInputsSectionProps) {
  const { can } = useAuth();
  const [showVesselDialog, setShowVesselDialog] = useState(false);
  const [showDeclarationsDialog, setShowDeclarationsDialog] = useState(false);
  const [activeTab, setActiveTab] = useState('vessel');

  const canEdit = can('compliance:update');
  const isReadOnly = project.status === 'CLOSED';

  // Stats
  const vesselStats = getVesselIdentityCompleteness(project.vesselIdentity);
  const declarationsStats = getDeclarationsCompleteness(project.declarations);
  const standardsCount = project.appliedStandards?.length || 0;
  const systemsCount = project.systems?.length || 0;
  const refsCount = project.technicalReferences?.length || 0;

  // Project type check: only show for NEW_BUILD or if any inputs exist
  const isNewBuild = project.type === 'NEW_BUILD';
  const hasInputs =
    project.vesselIdentity ||
    project.declarations ||
    standardsCount > 0 ||
    systemsCount > 0 ||
    refsCount > 0;

  if (!isNewBuild && !hasInputs) {
    return null;
  }

  return (
    <TooltipProvider>
    <Card data-testid="compliance-inputs-section">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ClipboardList className="h-5 w-5 text-teal-600" />
          Compliance Inputs
        </CardTitle>
        <CardDescription>
          Structured data that feeds compliance documents. Edit here, not in the Technical Dossier.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-4">
            <TabsTrigger value="vessel" className="gap-1">
              <Ship className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Vessel</span>
            </TabsTrigger>
            <TabsTrigger value="declarations" className="gap-1">
              <FileText className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">DoC</span>
            </TabsTrigger>
            <TabsTrigger value="standards" className="gap-1">
              <BookOpen className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Standards</span>
            </TabsTrigger>
            <TabsTrigger value="systems" className="gap-1">
              <Settings2 className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Systems</span>
            </TabsTrigger>
            <TabsTrigger value="refs" className="gap-1">
              <Layers className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Refs</span>
            </TabsTrigger>
          </TabsList>

          {/* Vessel Identity Tab */}
          <TabsContent value="vessel">
            <VesselIdentityCard
              vesselIdentity={project.vesselIdentity}
              project={project}
              stats={vesselStats}
              canEdit={canEdit && !isReadOnly}
              onEdit={() => setShowVesselDialog(true)}
              onRefresh={onRefresh}
            />
          </TabsContent>

          {/* Declarations Tab */}
          <TabsContent value="declarations">
            <DeclarationsCard
              declarations={project.declarations}
              stats={declarationsStats}
              canEdit={canEdit && !isReadOnly}
              onEdit={() => setShowDeclarationsDialog(true)}
            />
          </TabsContent>

          {/* Standards Tab */}
          <TabsContent value="standards">
            <StandardsOverviewCard
              standardsCount={standardsCount}
              appliedStandards={project.appliedStandards}
            />
          </TabsContent>

          {/* Systems Tab */}
          <TabsContent value="systems">
            <SystemsOverviewCard
              systemsCount={systemsCount}
              systems={project.systems}
            />
          </TabsContent>

          {/* Technical References Tab */}
          <TabsContent value="refs">
            <TechnicalRefsCard
              refsCount={refsCount}
              technicalReferences={project.technicalReferences}
            />
          </TabsContent>
        </Tabs>
      </CardContent>

      {/* Vessel Identity Dialog */}
      <VesselIdentityDialog
        open={showVesselDialog}
        onOpenChange={setShowVesselDialog}
        project={project}
        onRefresh={onRefresh}
      />

      {/* Declarations Dialog */}
      <DeclarationsDialog
        open={showDeclarationsDialog}
        onOpenChange={setShowDeclarationsDialog}
        project={project}
        onRefresh={onRefresh}
      />
    </Card>
    </TooltipProvider>
  );
}

// ============================================
// VESSEL IDENTITY CARD
// ============================================

interface VesselIdentityCardProps {
  vesselIdentity?: VesselIdentity;
  project: Project;
  stats: { complete: number; total: number };
  canEdit: boolean;
  onEdit: () => void;
  onRefresh: () => void;
}

function VesselIdentityCard({ vesselIdentity, project, stats, canEdit, onEdit, onRefresh }: VesselIdentityCardProps) {
  const { user } = useAuth();
  const isComplete = stats.complete === stats.total;
  const [boatModel, setBoatModel] = useState<BoatModel | null>(null);
  const [initializing, setInitializing] = useState(false);
  const [showReinitConfirm, setShowReinitConfirm] = useState(false);

  // Check if project has a boat model selected
  const hasBoatModel = !!project.configuration.boatModelVersionId;
  const hasExistingInit = !!vesselIdentity?.initFromModel;

  // Load boat model on mount
  useState(() => {
    if (project.configuration.boatModelVersionId) {
      BoatModelService.getById(project.configuration.boatModelVersionId).then(setBoatModel);
    }
  });

  // Handle initialize from boat model
  async function handleInitFromModel() {
    if (!user) return;

    // If already initialized, show confirmation
    if (hasExistingInit) {
      setShowReinitConfirm(true);
      return;
    }

    await performInit();
  }

  async function performInit() {
    if (!user) return;

    setInitializing(true);
    try {
      const result = await ProjectService.initializeVesselIdentityFromBoatModel(
        project.id,
        { userId: user.id, userName: user.name }
      );
      if (result.ok) {
        onRefresh();
      } else {
        console.error('Failed to initialize vessel identity:', result.error);
      }
    } catch (error) {
      console.error('Failed to initialize vessel identity:', error);
    } finally {
      setInitializing(false);
      setShowReinitConfirm(false);
    }
  }

  // Format initialization timestamp
  function formatInitDate(isoDate: string): string {
    const date = new Date(isoDate);
    return date.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Ship className="h-5 w-5 text-slate-500" />
          <h4 className="font-medium text-slate-900">Vessel Identity & Description</h4>
          <Badge
            variant="outline"
            className={isComplete ? 'border-green-300 text-green-700' : 'border-amber-300 text-amber-700'}
          >
            {stats.complete}/{stats.total} fields
          </Badge>
        </div>
        <div className="flex items-center gap-2">
          {canEdit && hasBoatModel && (
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleInitFromModel}
                  disabled={initializing}
                  className="text-teal-700 border-teal-300 hover:bg-teal-50"
                >
                  {hasExistingInit ? (
                    <RefreshCw className={`h-3.5 w-3.5 mr-1 ${initializing ? 'animate-spin' : ''}`} />
                  ) : (
                    <Download className="h-3.5 w-3.5 mr-1" />
                  )}
                  {hasExistingInit ? 'Re-initialize' : 'Init from Model'}
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs">
                  {hasExistingInit
                    ? 'Re-copy values from Boat Model (will overwrite current values)'
                    : 'Copy vessel specifications from the selected Boat Model'}
                </p>
              </TooltipContent>
            </Tooltip>
          )}
          {canEdit && (
            <Button variant="outline" size="sm" onClick={onEdit}>
              <Edit className="h-3.5 w-3.5 mr-1" />
              Edit
            </Button>
          )}
        </div>
      </div>

      {/* Initialization metadata hint */}
      {vesselIdentity?.initFromModel && (
        <div className="flex items-center gap-2 text-xs text-slate-500 bg-slate-50 px-3 py-2 rounded-lg">
          <Download className="h-3.5 w-3.5 text-teal-600" />
          <span>
            Initialized from <strong className="text-slate-700">{vesselIdentity.initFromModel.boatModelName}</strong>
            {' '}on {formatInitDate(vesselIdentity.initFromModel.initializedAt)}
          </span>
          <span className="text-slate-400">—</span>
          <span className="text-slate-400">All fields remain editable</span>
        </div>
      )}

      {!vesselIdentity ? (
        <div className="p-6 bg-slate-50 rounded-lg text-center">
          <AlertCircle className="h-8 w-8 text-slate-300 mx-auto mb-2" />
          <p className="text-sm text-slate-500">No vessel identity data entered yet.</p>
          <div className="flex items-center justify-center gap-2 mt-3">
            {canEdit && hasBoatModel && (
              <Button
                variant="default"
                size="sm"
                onClick={handleInitFromModel}
                disabled={initializing}
                className="bg-teal-600 hover:bg-teal-700"
              >
                <Download className="h-3.5 w-3.5 mr-1" />
                Initialize from Boat Model
              </Button>
            )}
            {canEdit && (
              <Button variant="outline" size="sm" onClick={onEdit}>
                <Plus className="h-3.5 w-3.5 mr-1" />
                Enter Manually
              </Button>
            )}
          </div>
          {!hasBoatModel && canEdit && (
            <p className="text-xs text-slate-400 mt-2">
              Select a Boat Model in Configuration to enable auto-initialization.
            </p>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <VesselField
            label="Model Name"
            value={vesselIdentity.modelName || project.title}
            fieldName="modelName"
            initFromModel={vesselIdentity.initFromModel}
            boatModelValue={boatModel?.name}
          />
          <VesselField
            label="WIN"
            value={vesselIdentity.win || project.win}
            fieldName="win"
            initFromModel={vesselIdentity.initFromModel}
            isProjectSpecific
          />
          <VesselField
            label="Builder"
            value={vesselIdentity.builderName}
            fieldName="builderName"
            initFromModel={vesselIdentity.initFromModel}
          />
          <VesselField
            label="Design Category"
            value={vesselIdentity.designCategory}
            fieldName="designCategory"
            initFromModel={vesselIdentity.initFromModel}
            boatModelValue={boatModel?.ceCategory}
          />
          <VesselField
            label="Max Persons"
            value={vesselIdentity.maxPersons?.toString()}
            fieldName="maxPersons"
            initFromModel={vesselIdentity.initFromModel}
            boatModelValue={boatModel?.maxPassengers?.toString()}
          />
          <VesselField
            label="LOA"
            value={vesselIdentity.loaMeters ? `${vesselIdentity.loaMeters}m` : undefined}
            fieldName="loaMeters"
            initFromModel={vesselIdentity.initFromModel}
            boatModelValue={boatModel?.lengthM ? `${boatModel.lengthM}m` : undefined}
          />
          <VesselField
            label="Year"
            value={vesselIdentity.yearOfConstruction}
            fieldName="yearOfConstruction"
            initFromModel={vesselIdentity.initFromModel}
            isProjectSpecific
          />
          <VesselField
            label="Intended Use"
            value={vesselIdentity.intendedUse}
            fieldName="intendedUse"
            initFromModel={vesselIdentity.initFromModel}
            isProjectSpecific
          />
        </div>
      )}

      <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
        <div className="flex items-start gap-2">
          <Info className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
          <p className="text-xs text-blue-700">
            This data feeds the Declaration of Conformity, Owner's Manual, and Builder's Plate.
            Edit here to update all documents.
          </p>
        </div>
      </div>

      {/* Re-initialization confirmation dialog */}
      <AlertDialog open={showReinitConfirm} onOpenChange={setShowReinitConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Re-initialize Vessel Identity?</AlertDialogTitle>
            <AlertDialogDescription>
              This will overwrite the current vessel identity values with data from the selected Boat Model.
              Project-specific fields (WIN, Year, Intended Use) will be preserved.
              <br /><br />
              <strong>This action cannot be undone.</strong>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={initializing}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={performInit}
              disabled={initializing}
              className="bg-teal-600 hover:bg-teal-700"
            >
              {initializing ? 'Initializing...' : 'Re-initialize'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ============================================
// VESSEL FIELD WITH SOURCE HINT
// ============================================

interface VesselFieldProps {
  label: string;
  value?: string;
  fieldName: string;
  initFromModel?: VesselIdentityInit;
  boatModelValue?: string;
  isProjectSpecific?: boolean;
}

function VesselField({
  label,
  value,
  fieldName,
  initFromModel,
  boatModelValue,
  isProjectSpecific = false,
}: VesselFieldProps) {
  const dossierEvidence = getFieldDossierEvidence(fieldName);

  // Determine source hint
  let sourceHint: 'model' | 'overridden' | 'project' | null = null;
  if (initFromModel && !isProjectSpecific) {
    if (boatModelValue && value === boatModelValue) {
      sourceHint = 'model';
    } else if (boatModelValue && value !== boatModelValue) {
      sourceHint = 'overridden';
    } else if (!boatModelValue && value) {
      sourceHint = 'model'; // Assume from model if we have a value and init happened
    }
  } else if (isProjectSpecific && value) {
    sourceHint = 'project';
  }

  return (
    <div className="p-2 bg-slate-50 rounded">
      <div className="flex items-center gap-1">
        <p className="text-[10px] text-slate-500 uppercase tracking-wider">{label}</p>
        {sourceHint === 'model' && (
          <Tooltip>
            <TooltipTrigger>
              <span className="text-[9px] bg-teal-100 text-teal-700 px-1 rounded">Model</span>
            </TooltipTrigger>
            <TooltipContent>
              <p className="text-xs">Value from Boat Model</p>
            </TooltipContent>
          </Tooltip>
        )}
        {sourceHint === 'overridden' && (
          <Tooltip>
            <TooltipTrigger>
              <span className="text-[9px] bg-amber-100 text-amber-700 px-1 rounded">Edited</span>
            </TooltipTrigger>
            <TooltipContent>
              <p className="text-xs">Modified from Boat Model value</p>
            </TooltipContent>
          </Tooltip>
        )}
        {sourceHint === 'project' && (
          <Tooltip>
            <TooltipTrigger>
              <span className="text-[9px] bg-slate-200 text-slate-600 px-1 rounded">Project</span>
            </TooltipTrigger>
            <TooltipContent>
              <p className="text-xs">Project-specific value</p>
            </TooltipContent>
          </Tooltip>
        )}
      </div>
      <p className={`text-sm ${value ? 'text-slate-900' : 'text-slate-400 italic'}`}>
        {value || 'Not set'}
      </p>
      {dossierEvidence && value && (
        <DossierSectionHint
          sectionId={dossierEvidence.sectionId}
          sectionTitle={dossierEvidence.sectionTitle}
          className="mt-1"
        />
      )}
    </div>
  );
}

// ============================================
// DECLARATIONS CARD
// ============================================

interface DeclarationsCardProps {
  declarations?: ComplianceDeclarations;
  stats: { complete: number; total: number };
  canEdit: boolean;
  onEdit: () => void;
}

function DeclarationsCard({ declarations, stats, canEdit, onEdit }: DeclarationsCardProps) {
  const isComplete = stats.complete === stats.total;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FileText className="h-5 w-5 text-slate-500" />
          <h4 className="font-medium text-slate-900">Declaration of Conformity Data</h4>
          <Badge
            variant="outline"
            className={isComplete ? 'border-green-300 text-green-700' : 'border-amber-300 text-amber-700'}
          >
            {stats.complete}/{stats.total} fields
          </Badge>
        </div>
        {canEdit && (
          <Button variant="outline" size="sm" onClick={onEdit}>
            <Edit className="h-3.5 w-3.5 mr-1" />
            Edit
          </Button>
        )}
      </div>

      {!declarations ? (
        <div className="p-6 bg-slate-50 rounded-lg text-center">
          <AlertCircle className="h-8 w-8 text-slate-300 mx-auto mb-2" />
          <p className="text-sm text-slate-500">No declaration data entered yet.</p>
          {canEdit && (
            <Button variant="link" className="mt-2" onClick={onEdit}>
              <Plus className="h-3.5 w-3.5 mr-1" />
              Add Declaration Data
            </Button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <InfoField label="DoC Reference" value={declarations.docReferenceNumber} fieldName="docReferenceNumber" showDossierHint />
          <InfoField label="Issue Date" value={declarations.docIssueDate} fieldName="docIssueDate" showDossierHint />
          <InfoField label="Signatory" value={declarations.docSignatory} fieldName="docSignatory" showDossierHint />
          <InfoField label="Role" value={declarations.docSignatoryRole} />
          <InfoField label="Conformity Module" value={declarations.conformityModule} fieldName="conformityModule" showDossierHint />
          <InfoField label="Notified Body" value={declarations.notifiedBodyName} fieldName="notifiedBodyName" showDossierHint />
          <InfoField label="NB Number" value={declarations.notifiedBodyNumber} fieldName="notifiedBodyNumber" showDossierHint />
          <InfoField label="PCA" value={declarations.postConstructionAssessment ? 'Yes' : undefined} />
        </div>
      )}

      <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
        <div className="flex items-start gap-2">
          <Info className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
          <p className="text-xs text-blue-700">
            This data feeds the Declaration of Conformity document.
            The DoC is generated using these structured inputs.
          </p>
        </div>
      </div>
    </div>
  );
}

// ============================================
// STANDARDS OVERVIEW CARD
// ============================================

interface StandardsOverviewCardProps {
  standardsCount: number;
  appliedStandards?: Project['appliedStandards'];
}

function StandardsOverviewCard({ standardsCount, appliedStandards }: StandardsOverviewCardProps) {
  const harmonisedCount = appliedStandards?.filter((s) => s.isHarmonised).length || 0;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <BookOpen className="h-5 w-5 text-slate-500" />
        <h4 className="font-medium text-slate-900">Applied Standards</h4>
        <Badge variant="outline">{standardsCount} total</Badge>
        {harmonisedCount > 0 && (
          <Badge className="bg-green-100 text-green-700 border-0">
            {harmonisedCount} harmonised
          </Badge>
        )}
      </div>

      {standardsCount === 0 ? (
        <div className="p-6 bg-slate-50 rounded-lg text-center">
          <BookOpen className="h-8 w-8 text-slate-300 mx-auto mb-2" />
          <p className="text-sm text-slate-500">No standards applied yet.</p>
          <p className="text-xs text-slate-400 mt-1">
            Scroll down to the Applied Standards section to add standards.
          </p>
        </div>
      ) : (
        <div className="space-y-2 max-h-48 overflow-y-auto">
          {appliedStandards?.slice(0, 5).map((std) => (
            <div key={std.id} className="flex items-center gap-2 p-2 bg-slate-50 rounded text-sm">
              <code className="text-xs bg-slate-200 px-1.5 py-0.5 rounded">{std.code}</code>
              <span className="text-slate-600 truncate flex-1">{std.title}</span>
              {std.isHarmonised && (
                <Check className="h-3.5 w-3.5 text-green-600" />
              )}
              {std.tags && std.tags.length > 0 && (
                <div className="flex gap-1">
                  {std.tags.slice(0, 2).map((tag) => (
                    <span key={tag} className="text-[10px] bg-teal-100 text-teal-700 px-1 rounded">
                      {tag}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))}
          {standardsCount > 5 && (
            <p className="text-xs text-slate-400 text-center">
              +{standardsCount - 5} more standards
            </p>
          )}
        </div>
      )}

      <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
        <div className="flex items-start gap-2">
          <Info className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
          <p className="text-xs text-blue-700">
            Standards are a shared input. Documents reference standards by tag.
            Edit in the Applied Standards section below.
          </p>
        </div>
      </div>
    </div>
  );
}

// ============================================
// SYSTEMS OVERVIEW CARD
// ============================================

interface SystemsOverviewCardProps {
  systemsCount: number;
  systems?: string[];
}

function SystemsOverviewCard({ systemsCount, systems }: SystemsOverviewCardProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Settings2 className="h-5 w-5 text-slate-500" />
        <h4 className="font-medium text-slate-900">Vessel Systems</h4>
        <Badge variant="outline">{systemsCount} configured</Badge>
      </div>

      {systemsCount === 0 ? (
        <div className="p-6 bg-slate-50 rounded-lg text-center">
          <Settings2 className="h-8 w-8 text-slate-300 mx-auto mb-2" />
          <p className="text-sm text-slate-500">No vessel systems configured yet.</p>
          <p className="text-xs text-slate-400 mt-1">
            Scroll down to the Vessel Systems section to add systems.
          </p>
        </div>
      ) : (
        <div className="flex flex-wrap gap-2">
          {systems?.map((system) => (
            <Badge key={system} variant="outline" className="text-sm">
              {system.replace(/_/g, ' ')}
            </Badge>
          ))}
        </div>
      )}

      <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
        <div className="flex items-start gap-2">
          <Info className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
          <p className="text-xs text-blue-700">
            Systems drive Owner's Manual section inclusion.
            Edit in the Vessel Systems section below.
          </p>
        </div>
      </div>
    </div>
  );
}

// ============================================
// TECHNICAL REFS CARD
// ============================================

interface TechnicalRefsCardProps {
  refsCount: number;
  technicalReferences?: Project['technicalReferences'];
}

function TechnicalRefsCard({ refsCount, technicalReferences }: TechnicalRefsCardProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Layers className="h-5 w-5 text-slate-500" />
        <h4 className="font-medium text-slate-900">Technical References</h4>
        <Badge variant="outline">{refsCount} indexed</Badge>
      </div>

      {refsCount === 0 ? (
        <div className="p-6 bg-slate-50 rounded-lg text-center">
          <Layers className="h-8 w-8 text-slate-300 mx-auto mb-2" />
          <p className="text-sm text-slate-500">No technical references indexed yet.</p>
          <p className="text-xs text-slate-400 mt-1">
            Technical references are an index of drawings and calculations.
            Actual files are stored in the Technical Dossier.
          </p>
        </div>
      ) : (
        <div className="space-y-2 max-h-48 overflow-y-auto">
          {technicalReferences?.slice(0, 5).map((ref) => (
            <div key={ref.id} className="flex items-center gap-2 p-2 bg-slate-50 rounded text-sm">
              <code className="text-xs bg-slate-200 px-1.5 py-0.5 rounded">{ref.referenceCode}</code>
              <span className="text-slate-600 truncate flex-1">{ref.title}</span>
              <span className="text-[10px] text-slate-400">{ref.type}</span>
            </div>
          ))}
          {refsCount > 5 && (
            <p className="text-xs text-slate-400 text-center">
              +{refsCount - 5} more references
            </p>
          )}
        </div>
      )}

      <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
        <div className="flex items-start gap-2">
          <Info className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
          <p className="text-xs text-blue-700">
            This is an index only. Actual files should be uploaded to the Technical Dossier.
          </p>
        </div>
      </div>
    </div>
  );
}

// ============================================
// INFO FIELD HELPER
// ============================================

interface InfoFieldProps {
  label: string;
  value?: string;
  fieldName?: string;
  showDossierHint?: boolean;
}

function InfoField({ label, value, fieldName, showDossierHint = false }: InfoFieldProps) {
  const dossierEvidence = fieldName && showDossierHint ? getFieldDossierEvidence(fieldName) : null;

  return (
    <div className="p-2 bg-slate-50 rounded">
      <p className="text-[10px] text-slate-500 uppercase tracking-wider">{label}</p>
      <p className={`text-sm ${value ? 'text-slate-900' : 'text-slate-400 italic'}`}>
        {value || 'Not set'}
      </p>
      {dossierEvidence && value && (
        <DossierSectionHint
          sectionId={dossierEvidence.sectionId}
          sectionTitle={dossierEvidence.sectionTitle}
          className="mt-1"
        />
      )}
    </div>
  );
}

// ============================================
// VESSEL IDENTITY DIALOG
// ============================================

interface VesselIdentityDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  project: Project;
  onRefresh: () => void;
}

function VesselIdentityDialog({ open, onOpenChange, project, onRefresh }: VesselIdentityDialogProps) {
  const [form, setForm] = useState<VesselIdentity>(
    project.vesselIdentity || {
      modelName: project.title,
      win: project.win,
    }
  );
  const [saving, setSaving] = useState(false);

  async function handleSave() {
    setSaving(true);
    try {
      await ProjectRepository.update(project.id, {
        vesselIdentity: form,
        updatedAt: new Date().toISOString(),
      });
      onRefresh();
      onOpenChange(false);
    } catch (error) {
      console.error('Failed to save vessel identity:', error);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Ship className="h-5 w-5 text-teal-600" />
            Vessel Identity & Description
          </DialogTitle>
          <DialogDescription>
            Core identification data for CE compliance documentation.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Vessel/Model Name</Label>
              <Input
                value={form.modelName || ''}
                onChange={(e) => setForm({ ...form, modelName: e.target.value })}
                placeholder="e.g., Ranger 42"
              />
            </div>
            <div className="space-y-2">
              <Label>WIN</Label>
              <Input
                value={form.win || ''}
                onChange={(e) => setForm({ ...form, win: e.target.value })}
                placeholder="e.g., NL-ABC12345D123"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Builder Name</Label>
              <Input
                value={form.builderName || ''}
                onChange={(e) => setForm({ ...form, builderName: e.target.value })}
                placeholder="e.g., Navisol Yachts B.V."
              />
            </div>
            <div className="space-y-2">
              <Label>Builder Address</Label>
              <Input
                value={form.builderAddress || ''}
                onChange={(e) => setForm({ ...form, builderAddress: e.target.value })}
                placeholder="e.g., Harbour Street 1, Rotterdam"
              />
            </div>
          </div>

          <div className="grid grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>Design Category</Label>
              <Select
                value={form.designCategory || ''}
                onValueChange={(v) => setForm({ ...form, designCategory: v as VesselIdentity['designCategory'] })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="A">A - Ocean</SelectItem>
                  <SelectItem value="B">B - Offshore</SelectItem>
                  <SelectItem value="C">C - Inshore</SelectItem>
                  <SelectItem value="D">D - Sheltered</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Max Persons</Label>
              <Input
                type="number"
                value={form.maxPersons || ''}
                onChange={(e) => setForm({ ...form, maxPersons: Number.parseInt(e.target.value) || undefined })}
                placeholder="e.g., 8"
              />
            </div>
            <div className="space-y-2">
              <Label>Max Load (kg)</Label>
              <Input
                type="number"
                value={form.maxLoadKg || ''}
                onChange={(e) => setForm({ ...form, maxLoadKg: Number.parseInt(e.target.value) || undefined })}
                placeholder="e.g., 1200"
              />
            </div>
            <div className="space-y-2">
              <Label>Year Built</Label>
              <Input
                value={form.yearOfConstruction || ''}
                onChange={(e) => setForm({ ...form, yearOfConstruction: e.target.value })}
                placeholder="e.g., 2025"
                maxLength={4}
              />
            </div>
          </div>

          <div className="grid grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>LOA (m)</Label>
              <Input
                type="number"
                step="0.01"
                value={form.loaMeters || ''}
                onChange={(e) => setForm({ ...form, loaMeters: Number.parseFloat(e.target.value) || undefined })}
                placeholder="e.g., 12.80"
              />
            </div>
            <div className="space-y-2">
              <Label>Beam (m)</Label>
              <Input
                type="number"
                step="0.01"
                value={form.beamMeters || ''}
                onChange={(e) => setForm({ ...form, beamMeters: Number.parseFloat(e.target.value) || undefined })}
                placeholder="e.g., 4.20"
              />
            </div>
            <div className="space-y-2">
              <Label>Draft (m)</Label>
              <Input
                type="number"
                step="0.01"
                value={form.draftMeters || ''}
                onChange={(e) => setForm({ ...form, draftMeters: Number.parseFloat(e.target.value) || undefined })}
                placeholder="e.g., 1.10"
              />
            </div>
            <div className="space-y-2">
              <Label>Displacement (kg)</Label>
              <Input
                type="number"
                value={form.displacementKg || ''}
                onChange={(e) => setForm({ ...form, displacementKg: Number.parseInt(e.target.value) || undefined })}
                placeholder="e.g., 8500"
              />
            </div>
          </div>

          {/* GOVERNANCE: AI suggestions are NOT available for vessel identity fields.
              These are compliance-critical spec fields, not text-authoring surfaces.
              Users must enter these values manually. */}
          <div className="space-y-2">
            <Label>Intended Use</Label>
            <Textarea
              value={form.intendedUse || ''}
              onChange={(e) => setForm({ ...form, intendedUse: e.target.value })}
              placeholder="e.g., Recreational cruising, day sailing, overnight passages"
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label>Special Conditions / Limitations</Label>
            <Textarea
              value={form.specialConditions || ''}
              onChange={(e) => setForm({ ...form, specialConditions: e.target.value })}
              placeholder="e.g., Not suitable for use in wind speeds above Beaufort 6"
              rows={2}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={saving} className="bg-teal-600 hover:bg-teal-700">
            <Check className="h-4 w-4 mr-1" />
            {saving ? 'Saving...' : 'Save'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ============================================
// DECLARATIONS DIALOG
// ============================================

interface DeclarationsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  project: Project;
  onRefresh: () => void;
}

function DeclarationsDialog({ open, onOpenChange, project, onRefresh }: DeclarationsDialogProps) {
  const [form, setForm] = useState<ComplianceDeclarations>(project.declarations || {});
  const [saving, setSaving] = useState(false);

  async function handleSave() {
    setSaving(true);
    try {
      await ProjectRepository.update(project.id, {
        declarations: form,
        updatedAt: new Date().toISOString(),
      });
      onRefresh();
      onOpenChange(false);
    } catch (error) {
      console.error('Failed to save declarations:', error);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-teal-600" />
            Declaration of Conformity Data
          </DialogTitle>
          <DialogDescription>
            Conformity assessment data for the Declaration of Conformity.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>DoC Reference Number</Label>
              <Input
                value={form.docReferenceNumber || ''}
                onChange={(e) => setForm({ ...form, docReferenceNumber: e.target.value })}
                placeholder="e.g., DOC-2025-001"
              />
            </div>
            <div className="space-y-2">
              <Label>Issue Date</Label>
              <Input
                type="date"
                value={form.docIssueDate || ''}
                onChange={(e) => setForm({ ...form, docIssueDate: e.target.value })}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Signatory Name</Label>
              <Input
                value={form.docSignatory || ''}
                onChange={(e) => setForm({ ...form, docSignatory: e.target.value })}
                placeholder="e.g., Jan de Vries"
              />
            </div>
            <div className="space-y-2">
              <Label>Signatory Role</Label>
              <Input
                value={form.docSignatoryRole || ''}
                onChange={(e) => setForm({ ...form, docSignatoryRole: e.target.value })}
                placeholder="e.g., Technical Director"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Conformity Module</Label>
              <Select
                value={form.conformityModule || ''}
                onValueChange={(v) => setForm({ ...form, conformityModule: v as ComplianceDeclarations['conformityModule'] })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="A">A - Internal production control</SelectItem>
                  <SelectItem value="A1">A1 - Internal production control + supervised product testing</SelectItem>
                  <SelectItem value="B+C">B+C - EU-type examination + conformity to type</SelectItem>
                  <SelectItem value="B+D">B+D - EU-type examination + quality assurance</SelectItem>
                  <SelectItem value="B+E">B+E - EU-type examination + product quality assurance</SelectItem>
                  <SelectItem value="B+F">B+F - EU-type examination + product verification</SelectItem>
                  <SelectItem value="G">G - Unit verification</SelectItem>
                  <SelectItem value="H">H - Full quality assurance</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Notified Body Number</Label>
              <Input
                value={form.notifiedBodyNumber || ''}
                onChange={(e) => setForm({ ...form, notifiedBodyNumber: e.target.value })}
                placeholder="e.g., 0123"
              />
            </div>
            <div className="space-y-2">
              <Label>Notified Body Name</Label>
              <Input
                value={form.notifiedBodyName || ''}
                onChange={(e) => setForm({ ...form, notifiedBodyName: e.target.value })}
                placeholder="e.g., Bureau Veritas"
              />
            </div>
          </div>

          <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
            <div className="flex items-start gap-2">
              <AlertCircle className="h-4 w-4 text-amber-600 mt-0.5 flex-shrink-0" />
              <p className="text-xs text-amber-700">
                Notified Body involvement is only required for certain conformity assessment modules (A1, B+C, etc.)
                and for Design Category A boats.
              </p>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={saving} className="bg-teal-600 hover:bg-teal-700">
            <Check className="h-4 w-4 mr-1" />
            {saving ? 'Saving...' : 'Save'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
