/**
 * Shop Floor Orders Tab - v4
 * UI for managing shop floor order items (operational purchasing outside BOM).
 *
 * Can be used in two modes:
 * 1. Project-specific: Shows orders for a specific project
 * 2. General: Shows all orders (with filters)
 *
 * ============================================
 * GOVERNANCE: INTENT LOCK — OPERATIONAL LOG ONLY
 * ============================================
 * This is an operational log, NOT a procurement system.
 * - Status transitions are MANUAL ONLY (user clicks required)
 * - No automatic purchasing or workflow triggers
 * - No inventory management or stock tracking
 * - No BOM mutations or cost allocation
 * - No supplier suggestions or master data
 * - Priority field is INERT — no sorting or escalation logic
 * - No analytics, KPIs, or dashboards
 */

'use client';

import { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Package,
  Plus,
  Edit2,
  Trash2,
  Check,
  Clock,
  Truck,
  PackageCheck,
  Search,
  Filter,
  ChevronDown,
  ArrowRight,
  MoreVertical,
  AlertCircle,
  RefreshCw,
  Undo2,
  ShoppingCart,
  CircleDot,
} from 'lucide-react';
import type {
  OrderItem,
  OrderItemStatus,
  CreateOrderItemInput,
  UpdateOrderItemInput,
  OrderItemFilters,
} from '@/domain/models/order-item';
import { ORDER_ITEM_STATUS_LABELS, ORDER_ITEM_STATUS_COLORS } from '@/domain/models/order-item';
import { OrderItemService } from '@/domain/services/OrderItemService';
import { getDefaultAuditContext } from '@/v4/state/useAuth';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

// ============================================
// TYPES
// ============================================

interface ShopFloorOrdersTabProps {
  /** If provided, shows only orders for this project. If null/undefined, shows general overview. */
  projectId?: string | null;
  /** Project title for display (optional) */
  projectTitle?: string;
  /** Callback when order count changes (for badge updates) */
  onCountChange?: (counts: Record<OrderItemStatus, number>) => void;
  /** Show compact mode (less padding, smaller text) */
  compact?: boolean;
}

interface OrderFormData {
  description: string;
  quantity: string;
  unit: string;
  supplier: string;
  note: string;
  priority: 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT' | null;
}

// ============================================
// HELPERS
// ============================================

function getDefaultFormData(): OrderFormData {
  return {
    description: '',
    quantity: '',
    unit: 'pcs',
    supplier: '',
    note: '',
    priority: 'NORMAL',
  };
}

function formatDate(dateStr: string | null | undefined): string {
  if (!dateStr) return '-';
  return new Date(dateStr).toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function getStatusIcon(status: OrderItemStatus) {
  switch (status) {
    case 'NOT_ORDERED':
      return <CircleDot className="h-4 w-4" />;
    case 'ORDERED':
      return <Truck className="h-4 w-4" />;
    case 'RECEIVED':
      return <PackageCheck className="h-4 w-4" />;
  }
}

// ============================================
// MAIN COMPONENT
// ============================================

export function ShopFloorOrdersTab({
  projectId,
  projectTitle,
  onCountChange,
  compact = false,
}: ShopFloorOrdersTabProps) {
  const [items, setItems] = useState<OrderItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<OrderItemStatus | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Dialog states
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingItem, setEditingItem] = useState<OrderItem | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<OrderItem | null>(null);

  // Load items
  const loadItems = useCallback(async () => {
    setIsLoading(true);
    try {
      let data: OrderItem[];
      if (projectId) {
        data = await OrderItemService.getByProjectId(projectId);
      } else {
        data = await OrderItemService.getAll();
      }
      setItems(data);

      // Notify parent of counts
      if (onCountChange) {
        const counts = await (projectId
          ? OrderItemService.getProjectStatusCounts(projectId)
          : OrderItemService.getStatusCounts());
        onCountChange(counts);
      }
    } catch (error) {
      console.error('Failed to load order items:', error);
    } finally {
      setIsLoading(false);
    }
  }, [projectId, onCountChange]);

  useEffect(() => {
    loadItems();
  }, [loadItems]);

  // Filter items
  const filteredItems = useMemo(() => {
    let result = items;

    // Status filter
    if (statusFilter !== 'ALL') {
      result = result.filter((item) => item.status === statusFilter);
    }

    // Search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        (item) =>
          item.description.toLowerCase().includes(query) ||
          item.supplier?.toLowerCase().includes(query) ||
          item.note?.toLowerCase().includes(query)
      );
    }

    return result;
  }, [items, statusFilter, searchQuery]);

  // Status counts
  const statusCounts = useMemo(() => {
    return {
      NOT_ORDERED: items.filter((i) => i.status === 'NOT_ORDERED').length,
      ORDERED: items.filter((i) => i.status === 'ORDERED').length,
      RECEIVED: items.filter((i) => i.status === 'RECEIVED').length,
    };
  }, [items]);

  // ============================================
  // HANDLERS
  // ============================================

  async function handleCreate(data: OrderFormData) {
    const context = getDefaultAuditContext();
    const result = await OrderItemService.create(
      {
        projectId: projectId || null,
        description: data.description.trim(),
        quantity: data.quantity ? parseFloat(data.quantity) : null,
        unit: data.unit || null,
        supplier: data.supplier.trim() || null,
        note: data.note.trim() || null,
        priority: data.priority,
      },
      context
    );

    if (result.ok) {
      setShowAddDialog(false);
      loadItems();
    } else {
      alert(result.error);
    }
  }

  async function handleUpdate(id: string, data: OrderFormData) {
    const context = getDefaultAuditContext();
    const result = await OrderItemService.update(
      id,
      {
        description: data.description.trim(),
        quantity: data.quantity ? parseFloat(data.quantity) : null,
        unit: data.unit || null,
        supplier: data.supplier.trim() || null,
        note: data.note.trim() || null,
        priority: data.priority,
      },
      context
    );

    if (result.ok) {
      setEditingItem(null);
      loadItems();
    } else {
      alert(result.error);
    }
  }

  async function handleMarkAsOrdered(id: string) {
    const context = getDefaultAuditContext();
    const result = await OrderItemService.markAsOrdered(id, context);
    if (result.ok) {
      loadItems();
    } else {
      alert(result.error);
    }
  }

  async function handleMarkAsReceived(id: string) {
    const context = getDefaultAuditContext();
    const result = await OrderItemService.markAsReceived(id, context);
    if (result.ok) {
      loadItems();
    } else {
      alert(result.error);
    }
  }

  async function handleRevertToNotOrdered(id: string) {
    const context = getDefaultAuditContext();
    const result = await OrderItemService.revertToNotOrdered(id, context);
    if (result.ok) {
      loadItems();
    } else {
      alert(result.error);
    }
  }

  async function handleDelete(id: string) {
    const context = getDefaultAuditContext();
    const result = await OrderItemService.delete(id, context);
    if (result.ok) {
      setDeleteTarget(null);
      loadItems();
    } else {
      alert(result.error);
    }
  }

  // ============================================
  // RENDER
  // ============================================

  const title = projectId ? 'Project Orders' : 'Shop Floor Orders';
  const description = projectId
    ? `Order items for ${projectTitle || 'this project'} (outside BOM)`
    : 'All shop floor order items (outside BOM)';

  return (
    <TooltipProvider>
      <div className="space-y-4">
        {/* Header Card */}
        <Card>
          <CardHeader className={`flex flex-row items-center justify-between ${compact ? 'py-3' : ''}`}>
            <div>
              <CardTitle className="flex items-center gap-2">
                <ShoppingCart className="h-5 w-5 text-teal-600" />
                {title}
              </CardTitle>
              <CardDescription>{description}</CardDescription>
            </div>
            <Button onClick={() => setShowAddDialog(true)} size={compact ? 'sm' : 'default'}>
              <Plus className="h-4 w-4 mr-2" />
              Add Item
            </Button>
          </CardHeader>
          <CardContent>
            {/* Status Summary */}
            <div className="grid grid-cols-3 gap-3 mb-4">
              <button
                type="button"
                onClick={() => setStatusFilter(statusFilter === 'NOT_ORDERED' ? 'ALL' : 'NOT_ORDERED')}
                className={`p-3 rounded-lg border transition-colors ${
                  statusFilter === 'NOT_ORDERED'
                    ? 'border-slate-400 bg-slate-100'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <p className="text-xs text-slate-500">Not Ordered</p>
                <p className="text-xl font-bold text-slate-700">{statusCounts.NOT_ORDERED}</p>
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter(statusFilter === 'ORDERED' ? 'ALL' : 'ORDERED')}
                className={`p-3 rounded-lg border transition-colors ${
                  statusFilter === 'ORDERED'
                    ? 'border-amber-400 bg-amber-50'
                    : 'border-slate-200 hover:border-amber-200'
                }`}
              >
                <p className="text-xs text-amber-600">Ordered</p>
                <p className="text-xl font-bold text-amber-700">{statusCounts.ORDERED}</p>
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter(statusFilter === 'RECEIVED' ? 'ALL' : 'RECEIVED')}
                className={`p-3 rounded-lg border transition-colors ${
                  statusFilter === 'RECEIVED'
                    ? 'border-green-400 bg-green-50'
                    : 'border-slate-200 hover:border-green-200'
                }`}
              >
                <p className="text-xs text-green-600">Received</p>
                <p className="text-xl font-bold text-green-700">{statusCounts.RECEIVED}</p>
              </button>
            </div>

            {/* Search */}
            <div className="flex items-center gap-3 mb-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input
                  placeholder="Search items..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
              {statusFilter !== 'ALL' && (
                <Button variant="outline" size="sm" onClick={() => setStatusFilter('ALL')}>
                  <RefreshCw className="h-4 w-4 mr-1" />
                  Clear Filter
                </Button>
              )}
            </div>

            {/* Items List */}
            {isLoading ? (
              <div className="py-8 text-center text-slate-500">Loading...</div>
            ) : filteredItems.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="w-14 h-14 rounded-xl bg-slate-100 flex items-center justify-center mb-4">
                  <Package className="h-7 w-7 text-slate-400" />
                </div>
                <h4 className="text-base font-medium text-slate-900 mb-1">
                  {searchQuery || statusFilter !== 'ALL' ? 'No matching items' : 'No order items'}
                </h4>
                <p className="text-sm text-slate-500 max-w-xs mb-5">
                  {searchQuery || statusFilter !== 'ALL'
                    ? 'Try different search or filter.'
                    : 'Add items you need that are not in the BOM.'}
                </p>
                {!searchQuery && statusFilter === 'ALL' && (
                  <Button variant="outline" onClick={() => setShowAddDialog(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add First Item
                  </Button>
                )}
              </div>
            ) : (
              <div className="space-y-2">
                {filteredItems.map((item) => (
                  <OrderItemRow
                    key={item.id}
                    item={item}
                    compact={compact}
                    onEdit={() => setEditingItem(item)}
                    onDelete={() => setDeleteTarget(item)}
                    onMarkAsOrdered={() => handleMarkAsOrdered(item.id)}
                    onMarkAsReceived={() => handleMarkAsReceived(item.id)}
                    onRevert={() => handleRevertToNotOrdered(item.id)}
                  />
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Add Dialog */}
      <OrderItemDialog
        open={showAddDialog}
        onOpenChange={setShowAddDialog}
        onSave={handleCreate}
        title="Add Order Item"
        description={
          projectId
            ? 'Add an item to order for this project.'
            : 'Add a general order item (not linked to a project).'
        }
      />

      {/* Edit Dialog */}
      {editingItem && (
        <OrderItemDialog
          open={!!editingItem}
          onOpenChange={(open) => !open && setEditingItem(null)}
          onSave={(data) => handleUpdate(editingItem.id, data)}
          initialData={editingItem}
          title="Edit Order Item"
          description="Update the order item details."
        />
      )}

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Order Item</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete <strong>{deleteTarget?.description}</strong>?
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteTarget && handleDelete(deleteTarget.id)}
              className="bg-red-600 hover:bg-red-700"
            >
              <Trash2 className="h-4 w-4 mr-1" />
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </TooltipProvider>
  );
}

// ============================================
// ORDER ITEM ROW
// ============================================

interface OrderItemRowProps {
  item: OrderItem;
  compact?: boolean;
  onEdit: () => void;
  onDelete: () => void;
  onMarkAsOrdered: () => void;
  onMarkAsReceived: () => void;
  onRevert: () => void;
}

function OrderItemRow({
  item,
  compact,
  onEdit,
  onDelete,
  onMarkAsOrdered,
  onMarkAsReceived,
  onRevert,
}: OrderItemRowProps) {
  const statusColors = ORDER_ITEM_STATUS_COLORS[item.status];

  return (
    <div
      className={`flex items-start gap-4 p-3 border rounded-lg hover:bg-slate-50 transition-colors ${
        item.status === 'RECEIVED' ? 'opacity-70' : ''
      }`}
    >
      {/* Status Icon */}
      <div className={`p-2 rounded-lg ${statusColors.bg}`}>
        <span className={statusColors.text}>{getStatusIcon(item.status)}</span>
      </div>

      {/* Main Content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className={`font-medium text-slate-900 ${compact ? 'text-sm' : ''}`}>
              {item.description}
            </p>
            <div className="flex items-center gap-2 mt-1 text-xs text-slate-500">
              {item.quantity && (
                <span>
                  {item.quantity} {item.unit || 'pcs'}
                </span>
              )}
              {item.supplier && (
                <>
                  <span>•</span>
                  <span>{item.supplier}</span>
                </>
              )}
              {/* GOVERNANCE: Priority is INERT METADATA — no color coding implying escalation */}
              {item.priority && item.priority !== 'NORMAL' && (
                <>
                  <span>•</span>
                  <Badge
                    variant="outline"
                    className="text-[10px] py-0 border-slate-200 text-slate-500"
                  >
                    {item.priority}
                  </Badge>
                </>
              )}
            </div>
            {item.note && (
              <p className="text-xs text-slate-500 mt-1 italic truncate max-w-[400px]">{item.note}</p>
            )}
          </div>

          {/* Status Badge */}
          <Badge className={`${statusColors.bg} ${statusColors.text} border-0 text-xs`}>
            {ORDER_ITEM_STATUS_LABELS[item.status]}
          </Badge>
        </div>

        {/* Timestamps */}
        {(item.orderedAt || item.receivedAt) && (
          <div className="flex items-center gap-3 mt-2 text-[11px] text-slate-400">
            {item.orderedAt && (
              <span className="flex items-center gap-1">
                <Truck className="h-3 w-3" />
                Ordered: {formatDate(item.orderedAt)}
              </span>
            )}
            {item.receivedAt && (
              <span className="flex items-center gap-1">
                <PackageCheck className="h-3 w-3" />
                Received: {formatDate(item.receivedAt)}
              </span>
            )}
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="flex items-center gap-1">
        {/* Primary Action Button */}
        {item.status === 'NOT_ORDERED' && (
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className="h-8 gap-1 border-amber-200 text-amber-700 hover:bg-amber-50"
                onClick={onMarkAsOrdered}
              >
                <Truck className="h-3.5 w-3.5" />
                Mark Ordered
              </Button>
            </TooltipTrigger>
            <TooltipContent>Mark this item as ordered</TooltipContent>
          </Tooltip>
        )}
        {item.status === 'ORDERED' && (
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className="h-8 gap-1 border-green-200 text-green-700 hover:bg-green-50"
                onClick={onMarkAsReceived}
              >
                <PackageCheck className="h-3.5 w-3.5" />
                Mark Received
              </Button>
            </TooltipTrigger>
            <TooltipContent>Mark this item as received</TooltipContent>
          </Tooltip>
        )}

        {/* More Actions Menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <MoreVertical className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            {item.status !== 'RECEIVED' && (
              <DropdownMenuItem onClick={onEdit}>
                <Edit2 className="h-4 w-4 mr-2" />
                Edit
              </DropdownMenuItem>
            )}
            {item.status === 'ORDERED' && (
              <DropdownMenuItem onClick={onRevert}>
                <Undo2 className="h-4 w-4 mr-2" />
                Revert to Not Ordered
              </DropdownMenuItem>
            )}
            {item.status === 'NOT_ORDERED' && (
              <>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={onDelete} className="text-red-600">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}

// ============================================
// ORDER ITEM DIALOG
// ============================================

interface OrderItemDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (data: OrderFormData) => void;
  initialData?: OrderItem;
  title: string;
  description: string;
}

function OrderItemDialog({
  open,
  onOpenChange,
  onSave,
  initialData,
  title,
  description,
}: OrderItemDialogProps) {
  const [formData, setFormData] = useState<OrderFormData>(() =>
    initialData
      ? {
          description: initialData.description,
          quantity: initialData.quantity?.toString() || '',
          unit: initialData.unit || 'pcs',
          supplier: initialData.supplier || '',
          note: initialData.note || '',
          priority: initialData.priority || 'NORMAL',
        }
      : getDefaultFormData()
  );

  // Reset form when dialog opens with new data
  useEffect(() => {
    if (open) {
      if (initialData) {
        setFormData({
          description: initialData.description,
          quantity: initialData.quantity?.toString() || '',
          unit: initialData.unit || 'pcs',
          supplier: initialData.supplier || '',
          note: initialData.note || '',
          priority: initialData.priority || 'NORMAL',
        });
      } else {
        setFormData(getDefaultFormData());
      }
    }
  }, [open, initialData]);

  function handleSubmit() {
    if (!formData.description.trim()) {
      alert('Description is required');
      return;
    }
    onSave(formData);
  }

  const isValid = formData.description.trim().length > 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShoppingCart className="h-5 w-5 text-teal-600" />
            {title}
          </DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
              placeholder="What do you need to order?"
              rows={2}
              autoFocus
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="quantity">Quantity</Label>
              <Input
                id="quantity"
                type="number"
                step="0.01"
                min="0"
                value={formData.quantity}
                onChange={(e) => setFormData((prev) => ({ ...prev, quantity: e.target.value }))}
                placeholder="e.g., 10"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="unit">Unit</Label>
              <Select
                value={formData.unit}
                onValueChange={(v) => setFormData((prev) => ({ ...prev, unit: v }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pcs">pcs</SelectItem>
                  <SelectItem value="set">set</SelectItem>
                  <SelectItem value="m">m</SelectItem>
                  <SelectItem value="kg">kg</SelectItem>
                  <SelectItem value="L">L</SelectItem>
                  <SelectItem value="box">box</SelectItem>
                  <SelectItem value="roll">roll</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="supplier">Supplier (optional)</Label>
            <Input
              id="supplier"
              value={formData.supplier}
              onChange={(e) => setFormData((prev) => ({ ...prev, supplier: e.target.value }))}
              placeholder="e.g., Supplier name"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="priority">Priority</Label>
            <Select
              value={formData.priority || 'NORMAL'}
              onValueChange={(v) =>
                setFormData((prev) => ({
                  ...prev,
                  priority: v as 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT',
                }))
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="LOW">Low</SelectItem>
                <SelectItem value="NORMAL">Normal</SelectItem>
                <SelectItem value="HIGH">High</SelectItem>
                <SelectItem value="URGENT">Urgent</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="note">Note (optional)</Label>
            <Textarea
              id="note"
              value={formData.note}
              onChange={(e) => setFormData((prev) => ({ ...prev, note: e.target.value }))}
              placeholder="Any additional notes..."
              rows={2}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={!isValid}>
            <Check className="h-4 w-4 mr-1" />
            {initialData ? 'Save Changes' : 'Add Item'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ============================================
// QUICK ADD COMPONENT (for embedding in other views)
// ============================================

interface QuickAddOrderItemProps {
  projectId?: string | null;
  onAdded?: () => void;
}

export function QuickAddOrderItem({ projectId, onAdded }: QuickAddOrderItemProps) {
  const [description, setDescription] = useState('');
  const [isAdding, setIsAdding] = useState(false);

  async function handleAdd() {
    if (!description.trim()) return;

    setIsAdding(true);
    try {
      const context = getDefaultAuditContext();
      const result = await OrderItemService.create(
        {
          projectId: projectId || null,
          description: description.trim(),
        },
        context
      );

      if (result.ok) {
        setDescription('');
        onAdded?.();
      } else {
        alert(result.error);
      }
    } finally {
      setIsAdding(false);
    }
  }

  return (
    <div className="flex items-center gap-2">
      <Input
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        placeholder="Quick add: What do you need?"
        className="flex-1"
        onKeyDown={(e) => {
          if (e.key === 'Enter' && description.trim()) {
            handleAdd();
          }
        }}
      />
      <Button
        onClick={handleAdd}
        disabled={!description.trim() || isAdding}
        size="sm"
      >
        <Plus className="h-4 w-4 mr-1" />
        Add
      </Button>
    </div>
  );
}
