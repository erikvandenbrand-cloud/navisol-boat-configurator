/**
 * Shop Floor Orders Screen - v4 Portfolio Level
 * Shows all shop floor order items with filters.
 *
 * ============================================
 * GOVERNANCE: INTENT LOCK — OPERATIONAL LOG ONLY
 * ============================================
 * This is an operational log, NOT a procurement system.
 * - All orders in one place (project-specific + general)
 * - Filter by status, project, creator
 * - Quick actions for status transitions (MANUAL ONLY)
 * - No analytics, KPIs, or dashboards
 * - No supplier management or suggestions
 * - No purchasing workflows or approvals
 * - Priority field is INERT — no sorting or escalation logic
 * - Must NOT expand into planning or purchasing dashboards
 */

'use client';

import { useState, useEffect, useMemo, useCallback } from 'react';
import {
  ShoppingCart,
  Package,
  Plus,
  Edit2,
  Trash2,
  Check,
  Truck,
  PackageCheck,
  Search,
  Filter,
  RefreshCw,
  Undo2,
  MoreVertical,
  CircleDot,
  Ship,
  Layers,
} from 'lucide-react';
import type {
  OrderItem,
  OrderItemStatus,
  OrderItemFilters,
  Project,
} from '@/domain/models';
import { ORDER_ITEM_STATUS_LABELS, ORDER_ITEM_STATUS_COLORS } from '@/domain/models/order-item';
import { OrderItemService } from '@/domain/services/OrderItemService';
import { ProjectRepository } from '@/data/repositories';
import { getDefaultAuditContext } from '@/v4/state/useAuth';
import { ShopFloorOrdersTab, QuickAddOrderItem } from '@/v4/components/ShopFloorOrdersTab';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

// ============================================
// TYPES
// ============================================

interface ShopFloorOrdersScreenProps {
  onNavigateToProject?: (projectId: string) => void;
}

// ============================================
// MAIN COMPONENT
// ============================================

export function ShopFloorOrdersScreen({ onNavigateToProject }: ShopFloorOrdersScreenProps) {
  const [activeTab, setActiveTab] = useState<'all' | 'general' | 'by-project'>('all');
  const [items, setItems] = useState<OrderItem[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<OrderItemStatus | 'ALL'>('ALL');
  const [projectFilter, setProjectFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Load data
  const loadData = useCallback(async () => {
    setIsLoading(true);
    try {
      const [orderItems, allProjects] = await Promise.all([
        OrderItemService.getAll(),
        ProjectRepository.getAll(),
      ]);
      setItems(orderItems);
      // Only show projects in production or with orders
      const projectIds = new Set(orderItems.filter(i => i.projectId).map(i => i.projectId));
      const relevantProjects = allProjects.filter(
        p => ['IN_PRODUCTION', 'ORDER_CONFIRMED'].includes(p.status) || projectIds.has(p.id)
      );
      setProjects(relevantProjects);
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Filter items
  const filteredItems = useMemo(() => {
    let result = items;

    // Tab filter
    if (activeTab === 'general') {
      result = result.filter(item => !item.projectId);
    } else if (activeTab === 'by-project' && projectFilter !== 'ALL') {
      result = result.filter(item => item.projectId === projectFilter);
    }

    // Status filter
    if (statusFilter !== 'ALL') {
      result = result.filter(item => item.status === statusFilter);
    }

    // Search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        item =>
          item.description.toLowerCase().includes(query) ||
          item.supplier?.toLowerCase().includes(query) ||
          item.note?.toLowerCase().includes(query)
      );
    }

    return result;
  }, [items, activeTab, statusFilter, projectFilter, searchQuery]);

  // Status counts
  const statusCounts = useMemo(() => {
    return {
      NOT_ORDERED: items.filter(i => i.status === 'NOT_ORDERED').length,
      ORDERED: items.filter(i => i.status === 'ORDERED').length,
      RECEIVED: items.filter(i => i.status === 'RECEIVED').length,
    };
  }, [items]);

  // General vs project counts
  const generalCount = items.filter(i => !i.projectId).length;
  const projectCount = items.filter(i => i.projectId).length;

  // Get project title
  function getProjectTitle(projectId: string | null | undefined): string {
    if (!projectId) return 'General';
    const project = projects.find(p => p.id === projectId);
    return project?.title || 'Unknown Project';
  }

  // ============================================
  // HANDLERS
  // ============================================

  async function handleMarkAsOrdered(id: string) {
    const context = getDefaultAuditContext();
    const result = await OrderItemService.markAsOrdered(id, context);
    if (result.ok) {
      loadData();
    } else {
      alert(result.error);
    }
  }

  async function handleMarkAsReceived(id: string) {
    const context = getDefaultAuditContext();
    const result = await OrderItemService.markAsReceived(id, context);
    if (result.ok) {
      loadData();
    } else {
      alert(result.error);
    }
  }

  async function handleRevert(id: string) {
    const context = getDefaultAuditContext();
    const result = await OrderItemService.revertToNotOrdered(id, context);
    if (result.ok) {
      loadData();
    } else {
      alert(result.error);
    }
  }

  async function handleDelete(id: string) {
    if (!confirm('Delete this order item?')) return;
    const context = getDefaultAuditContext();
    const result = await OrderItemService.delete(id, context);
    if (result.ok) {
      loadData();
    } else {
      alert(result.error);
    }
  }

  // ============================================
  // RENDER
  // ============================================

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-3">
            <ShoppingCart className="h-7 w-7 text-teal-600" />
            Shop Floor Orders
          </h1>
          <p className="text-slate-600 mt-1">
            Operational purchasing for parts, tools, and materials outside the BOM
          </p>
        </div>
        <Button onClick={loadData} variant="outline" disabled={isLoading}>
          <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {/* Status Summary Cards */}
      <div className="grid grid-cols-4 gap-4">
        <Card className="bg-slate-50">
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-500">Total Items</p>
                <p className="text-2xl font-bold text-slate-900">{items.length}</p>
              </div>
              <Package className="h-8 w-8 text-slate-400" />
            </div>
            <div className="mt-2 flex items-center gap-2 text-xs text-slate-500">
              <span>{generalCount} general</span>
              <span>•</span>
              <span>{projectCount} project-specific</span>
            </div>
          </CardContent>
        </Card>

        <button
          type="button"
          onClick={() => setStatusFilter(statusFilter === 'NOT_ORDERED' ? 'ALL' : 'NOT_ORDERED')}
          className={`text-left transition-colors rounded-lg ${
            statusFilter === 'NOT_ORDERED' ? 'ring-2 ring-slate-400' : ''
          }`}
        >
          <Card className="h-full">
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">Not Ordered</p>
                  <p className="text-2xl font-bold text-slate-700">{statusCounts.NOT_ORDERED}</p>
                </div>
                <CircleDot className="h-8 w-8 text-slate-400" />
              </div>
              <p className="mt-2 text-xs text-slate-500">Needs attention</p>
            </CardContent>
          </Card>
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter(statusFilter === 'ORDERED' ? 'ALL' : 'ORDERED')}
          className={`text-left transition-colors rounded-lg ${
            statusFilter === 'ORDERED' ? 'ring-2 ring-amber-400' : ''
          }`}
        >
          <Card className="h-full bg-amber-50">
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-amber-600">Ordered</p>
                  <p className="text-2xl font-bold text-amber-700">{statusCounts.ORDERED}</p>
                </div>
                <Truck className="h-8 w-8 text-amber-400" />
              </div>
              <p className="mt-2 text-xs text-amber-600">Awaiting delivery</p>
            </CardContent>
          </Card>
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter(statusFilter === 'RECEIVED' ? 'ALL' : 'RECEIVED')}
          className={`text-left transition-colors rounded-lg ${
            statusFilter === 'RECEIVED' ? 'ring-2 ring-green-400' : ''
          }`}
        >
          <Card className="h-full bg-green-50">
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-green-600">Received</p>
                  <p className="text-2xl font-bold text-green-700">{statusCounts.RECEIVED}</p>
                </div>
                <PackageCheck className="h-8 w-8 text-green-400" />
              </div>
              <p className="mt-2 text-xs text-green-600">Completed</p>
            </CardContent>
          </Card>
        </button>
      </div>

      {/* Quick Add */}
      <Card>
        <CardHeader className="py-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <Plus className="h-4 w-4 text-teal-600" />
            Quick Add General Order
          </CardTitle>
        </CardHeader>
        <CardContent className="py-3">
          <QuickAddOrderItem projectId={null} onAdded={loadData} />
        </CardContent>
      </Card>

      {/* Tabs: All / General / By Project */}
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as typeof activeTab)}>
        <div className="flex items-center justify-between mb-4">
          <TabsList>
            <TabsTrigger value="all">
              All Orders
              <Badge variant="secondary" className="ml-2">{items.length}</Badge>
            </TabsTrigger>
            <TabsTrigger value="general">
              General
              <Badge variant="secondary" className="ml-2">{generalCount}</Badge>
            </TabsTrigger>
            <TabsTrigger value="by-project">
              By Project
              <Badge variant="secondary" className="ml-2">{projectCount}</Badge>
            </TabsTrigger>
          </TabsList>

          {/* Filters */}
          <div className="flex items-center gap-3">
            {/* Project filter (only for by-project tab) */}
            {activeTab === 'by-project' && (
              <Select value={projectFilter} onValueChange={setProjectFilter}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Select project" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">All Projects</SelectItem>
                  {projects.map(project => (
                    <SelectItem key={project.id} value={project.id}>
                      {project.projectNumber} - {project.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}

            {/* Search */}
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <Input
                placeholder="Search items..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>

            {/* Clear filters */}
            {(statusFilter !== 'ALL' || searchQuery) && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setStatusFilter('ALL');
                  setSearchQuery('');
                }}
              >
                <RefreshCw className="h-4 w-4 mr-1" />
                Clear
              </Button>
            )}
          </div>
        </div>

        {/* All Orders */}
        <TabsContent value="all">
          <OrderItemsList
            items={filteredItems}
            projects={projects}
            isLoading={isLoading}
            onMarkAsOrdered={handleMarkAsOrdered}
            onMarkAsReceived={handleMarkAsReceived}
            onRevert={handleRevert}
            onDelete={handleDelete}
            onNavigateToProject={onNavigateToProject}
            showProject
          />
        </TabsContent>

        {/* General Orders */}
        <TabsContent value="general">
          <OrderItemsList
            items={filteredItems}
            projects={projects}
            isLoading={isLoading}
            onMarkAsOrdered={handleMarkAsOrdered}
            onMarkAsReceived={handleMarkAsReceived}
            onRevert={handleRevert}
            onDelete={handleDelete}
            onNavigateToProject={onNavigateToProject}
            showProject={false}
          />
        </TabsContent>

        {/* By Project */}
        <TabsContent value="by-project">
          <OrderItemsList
            items={filteredItems}
            projects={projects}
            isLoading={isLoading}
            onMarkAsOrdered={handleMarkAsOrdered}
            onMarkAsReceived={handleMarkAsReceived}
            onRevert={handleRevert}
            onDelete={handleDelete}
            onNavigateToProject={onNavigateToProject}
            showProject
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// ============================================
// ORDER ITEMS LIST COMPONENT
// ============================================

interface OrderItemsListProps {
  items: OrderItem[];
  projects: Project[];
  isLoading: boolean;
  onMarkAsOrdered: (id: string) => void;
  onMarkAsReceived: (id: string) => void;
  onRevert: (id: string) => void;
  onDelete: (id: string) => void;
  onNavigateToProject?: (projectId: string) => void;
  showProject: boolean;
}

function OrderItemsList({
  items,
  projects,
  isLoading,
  onMarkAsOrdered,
  onMarkAsReceived,
  onRevert,
  onDelete,
  onNavigateToProject,
  showProject,
}: OrderItemsListProps) {
  function getProjectInfo(projectId: string | null | undefined) {
    if (!projectId) return null;
    const project = projects.find(p => p.id === projectId);
    return project ? { id: project.id, number: project.projectNumber, title: project.title } : null;
  }

  function formatDate(dateStr: string | null | undefined): string {
    if (!dateStr) return '-';
    return new Date(dateStr).toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  if (isLoading) {
    return <div className="py-8 text-center text-slate-500">Loading...</div>;
  }

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <div className="w-14 h-14 rounded-xl bg-slate-100 flex items-center justify-center mb-4">
          <Package className="h-7 w-7 text-slate-400" />
        </div>
        <h4 className="text-base font-medium text-slate-900 mb-1">No order items</h4>
        <p className="text-sm text-slate-500 max-w-xs">
          Add items you need that are not in the BOM using the Quick Add above.
        </p>
      </div>
    );
  }

  return (
    <Card>
      <CardContent className="p-0">
        <div className="divide-y">
          {items.map(item => {
            const statusColors = ORDER_ITEM_STATUS_COLORS[item.status];
            const projectInfo = getProjectInfo(item.projectId);

            return (
              <div
                key={item.id}
                className={`flex items-start gap-4 p-4 hover:bg-slate-50 transition-colors ${
                  item.status === 'RECEIVED' ? 'opacity-60' : ''
                }`}
              >
                {/* Status Icon */}
                <div className={`p-2 rounded-lg ${statusColors.bg}`}>
                  <span className={statusColors.text}>
                    {item.status === 'NOT_ORDERED' && <CircleDot className="h-4 w-4" />}
                    {item.status === 'ORDERED' && <Truck className="h-4 w-4" />}
                    {item.status === 'RECEIVED' && <PackageCheck className="h-4 w-4" />}
                  </span>
                </div>

                {/* Main Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="font-medium text-slate-900">{item.description}</p>
                      <div className="flex items-center gap-2 mt-1 text-xs text-slate-500 flex-wrap">
                        {showProject && projectInfo && (
                          <button
                            type="button"
                            onClick={() => onNavigateToProject?.(projectInfo.id)}
                            className="flex items-center gap-1 text-teal-600 hover:text-teal-700 hover:underline"
                          >
                            <Ship className="h-3 w-3" />
                            {projectInfo.number}
                          </button>
                        )}
                        {showProject && !projectInfo && (
                          <Badge variant="outline" className="text-[10px] py-0">General</Badge>
                        )}
                        {item.quantity && (
                          <span>
                            {item.quantity} {item.unit || 'pcs'}
                          </span>
                        )}
                        {item.supplier && (
                          <>
                            <span>•</span>
                            <span>{item.supplier}</span>
                          </>
                        )}
                        {/* GOVERNANCE: Priority is INERT METADATA — no color coding implying escalation */}
                        {item.priority && item.priority !== 'NORMAL' && (
                          <Badge
                            variant="outline"
                            className="text-[10px] py-0 border-slate-200 text-slate-500"
                          >
                            {item.priority}
                          </Badge>
                        )}
                      </div>
                      {item.note && (
                        <p className="text-xs text-slate-500 mt-1 italic">{item.note}</p>
                      )}
                    </div>

                    {/* Status Badge */}
                    <Badge className={`${statusColors.bg} ${statusColors.text} border-0 text-xs flex-shrink-0`}>
                      {ORDER_ITEM_STATUS_LABELS[item.status]}
                    </Badge>
                  </div>

                  {/* Timestamps */}
                  <div className="flex items-center gap-4 mt-2 text-[11px] text-slate-400">
                    <span>Created: {formatDate(item.createdAt)}</span>
                    {item.orderedAt && <span>Ordered: {formatDate(item.orderedAt)}</span>}
                    {item.receivedAt && <span>Received: {formatDate(item.receivedAt)}</span>}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-1 flex-shrink-0">
                  {item.status === 'NOT_ORDERED' && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-8 gap-1 border-amber-200 text-amber-700 hover:bg-amber-50"
                      onClick={() => onMarkAsOrdered(item.id)}
                    >
                      <Truck className="h-3.5 w-3.5" />
                      Mark Ordered
                    </Button>
                  )}
                  {item.status === 'ORDERED' && (
                    <>
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-8 gap-1 border-green-200 text-green-700 hover:bg-green-50"
                        onClick={() => onMarkAsReceived(item.id)}
                      >
                        <PackageCheck className="h-3.5 w-3.5" />
                        Mark Received
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 w-8 p-0"
                        onClick={() => onRevert(item.id)}
                        title="Revert to Not Ordered"
                      >
                        <Undo2 className="h-4 w-4" />
                      </Button>
                    </>
                  )}
                  {item.status === 'NOT_ORDERED' && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                      onClick={() => onDelete(item.id)}
                      title="Delete"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
