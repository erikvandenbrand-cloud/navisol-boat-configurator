'use client';

import { V4App } from '@/v4/screens/V4App';

export default function V4Page() {
  return <V4App />;
}
