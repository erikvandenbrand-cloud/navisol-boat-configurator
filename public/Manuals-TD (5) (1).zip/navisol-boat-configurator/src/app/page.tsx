'use client';

import { V4App } from '@/v4/screens/V4App';

export default function Home() {
  return <V4App />;
}
