/**
 * Order Item Model - v4
 * Shop Floor Order List for operational purchasing outside BOM.
 *
 * ============================================
 * GOVERNANCE: INTENT LOCK — OPERATIONAL LOG ONLY
 * ============================================
 * This is an operational log, NOT a procurement system.
 * - No automatic purchasing
 * - No inventory management
 * - No accounting integration
 * - No background sync
 * - No BOM mutations
 * - No cost allocation logic
 * - No supplier master data or suggestions
 * - No analytics, KPIs, or dashboards
 * - No notifications or alerts
 *
 * Items can be:
 * - Project-specific (linked to a project)
 * - General (not linked to any project)
 *
 * All fields are either operational state or inert metadata.
 * No logic should depend on metadata fields for automation.
 */

import type { Entity } from './common';

// ============================================
// ORDER ITEM STATUS
// ============================================

/**
 * Order item status - explicit manual transitions only.
 * NOT_ORDERED → ORDERED → RECEIVED
 */
export type OrderItemStatus = 'NOT_ORDERED' | 'ORDERED' | 'RECEIVED';

export const ORDER_ITEM_STATUS_LABELS: Record<OrderItemStatus, string> = {
  NOT_ORDERED: 'Not Ordered',
  ORDERED: 'Ordered',
  RECEIVED: 'Received',
};

export const ORDER_ITEM_STATUS_COLORS: Record<OrderItemStatus, { bg: string; text: string; border: string }> = {
  NOT_ORDERED: { bg: 'bg-slate-100', text: 'text-slate-700', border: 'border-slate-200' },
  ORDERED: { bg: 'bg-amber-100', text: 'text-amber-700', border: 'border-amber-200' },
  RECEIVED: { bg: 'bg-green-100', text: 'text-green-700', border: 'border-green-200' },
};

// ============================================
// ORDER ITEM ENTITY
// ============================================

/**
 * Shop Floor Order Item.
 * Represents a part/tool/material that production staff needs,
 * which is NOT in the BOM.
 */
export interface OrderItem extends Entity {
  /** User who created this order item */
  createdByUserId: string;

  /** Project ID if project-specific, null/undefined for general orders */
  projectId?: string | null;

  /**
   * Description of the item (free text).
   * This is the PRIMARY way to describe items.
   */
  description: string;

  /**
   * Optional reference to a library article.
   * This is just a reference for convenience - no pricing logic.
   */
  articleId?: string | null;

  /**
   * Optional article code for display (cached from article if linked).
   */
  articleCode?: string | null;

  /** Quantity needed (optional) */
  quantity?: number | null;

  /** Unit of measure (optional, e.g., "pcs", "m", "set") */
  unit?: string | null;

  /** Current status - manual transitions only */
  status: OrderItemStatus;

  /** When the item was marked as ordered */
  orderedAt?: string | null;

  /** User who marked the item as ordered */
  orderedByUserId?: string | null;

  /** When the item was marked as received */
  receivedAt?: string | null;

  /** User who marked the item as received */
  receivedByUserId?: string | null;

  /** Free text notes */
  note?: string | null;

  /**
   * Supplier/vendor name (optional, free text).
   * GOVERNANCE: This is INERT METADATA only.
   * - No supplier master data or suggestions
   * - No auto-complete or reuse logic
   * - No purchasing workflow integration
   * - Purely informational for human reference
   */
  supplier?: string | null;

  /**
   * Priority level (optional).
   * GOVERNANCE: This is INERT METADATA only.
   * - No auto-sorting by priority
   * - No escalation logic or alerts
   * - No workflow dependencies
   * - Purely informational for human reference
   */
  priority?: 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT' | null;
}

// ============================================
// CREATE / UPDATE INPUTS
// ============================================

export interface CreateOrderItemInput {
  projectId?: string | null;
  description: string;
  articleId?: string | null;
  articleCode?: string | null;
  quantity?: number | null;
  unit?: string | null;
  note?: string | null;
  supplier?: string | null;
  priority?: 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT' | null;
}

export interface UpdateOrderItemInput {
  description?: string;
  articleId?: string | null;
  articleCode?: string | null;
  quantity?: number | null;
  unit?: string | null;
  note?: string | null;
  supplier?: string | null;
  priority?: 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT' | null;
}

// ============================================
// FILTERS
// ============================================

export interface OrderItemFilters {
  /** Filter by status */
  status?: OrderItemStatus | 'ALL';
  /** Filter by project ID (use 'GENERAL' for non-project items) */
  projectId?: string | 'GENERAL' | 'ALL';
  /** Filter by creator */
  createdByUserId?: string;
  /** Search in description */
  searchQuery?: string;
}
