# Navisol v4 - Development Status

## Completed: Sales Track v1 (v325)

### A) Extend Boat Model with Sales Content ✅ COMPLETE
- [x] Add salesSections, salesImages, salesSource to BoatModel interface (DONE in BoatModelService.ts)
- [x] Update BoatModelService with sales content fields in create/update (DONE)
- [x] Add Sales Content tab to BoatModelDialog.tsx
- [x] Implement CRUD UI for salesSections (add, reorder, delete)
- [x] Implement image slot management for salesImages
- [x] Add "Create Default Headings" helper button (creates empty placeholders only)

### B) Quote Deliverable - Customer Offer ✅ COMPLETE
- [x] Create CustomerOffer model (customer-offer.ts)
- [x] Create CustomerOfferService with block generation
- [x] Add "Generate Customer Offer" action in Quote screen
- [x] Implement block-based structure (Cover, Intro, Gallery, Equipment, Pricing, Terms)
- [x] Enable manual block editing after generation
- [x] Add HTML preview for Customer Offer
- [x] Add regeneration with confirmation (Option A: overwrite draft)

### Files Created/Modified:
- `src/domain/models/customer-offer.ts` — NEW: CustomerOffer model with blocks
- `src/domain/services/CustomerOfferService.ts` — NEW: Service for CRUD and generation
- `src/v4/components/CustomerOfferPanel.tsx` — NEW: UI component for quote deliverables
- `src/v4/components/BoatModelDialog.tsx` — Added Sales Content collapsible section
- `src/domain/models/index.ts` — Added customer-offer exports
- `src/domain/services/index.ts` — Added CustomerOfferService export
- `src/v4/screens/ProjectDetailScreen.tsx` — Integrated CustomerOfferPanel in Quotes tab

### Constraints Met:
- No background sync
- No CRM workflows
- No automation
- Explicit user actions only
- Internal content is single source of truth after import
- Production role cannot access sales authoring screens

## Completed (v324)

### Assignee Identity Stabilization ✅ COMPLETE
Adding stable User ID-based assignments while keeping backward compatibility.

**Deliverables:**
- [x] Added `assigneeUserIds` field to WorkItem model (parallel to legacy `assigneeIds`)
- [x] Added `sourceUserId` field to PlanningResource (tracks which User resource was created from)
- [x] Created UserSelectStable component with ID-based selection
- [x] Updated UserSelect to show "DisplayName — email" format for clarity
- [x] Created assignee-utils.ts with resolution helpers
- [x] Updated TaskService to support both fields on write
- [x] Updated PlanningTab/PlanningTaskDialog to store sourceUserId when creating resources

**Acceptance Criteria:**
- [x] Existing projects/tasks still show assignees correctly (backward compat via fallback)
- [x] New assignments store stable User ID in resources (sourceUserId)
- [x] No migration step required
- [x] No permissions logic uses department/labels

**Key Changes:**
- WorkItem.assigneeUserIds — Stable User ID-based assignees (v324+)
- PlanningResource.sourceUserId — Links resource to source User for stable identity
- UserSelectStable — New component for ID-based user selection
- assignee-utils.ts — Resolution utilities with fallback logic

## Completed (v323)

### Staff → User Unification ✅ COMPLETE
Consolidated Staff concept into User model.

**Step 1: Inventory ✅ COMPLETE**
- [x] Analyzed Staff model fields
- [x] Analyzed Staff usage locations
- [x] Compared with User model
- [x] Created inventory document: `.same/STAFF_USER_INVENTORY.md`

**Step 2: Target Model ✅ COMPLETE**
- [x] User model unchanged (department absorbs Staff.label)
- [x] No new fields required

**Step 3: Data Migration Plan ✅ COMPLETE**
- [x] Migration rules defined
- [x] Dry-run format specified

**Step 4: Implementation ✅ COMPLETE**
- [x] Created UserSelect component (replaces StaffSelect)
- [x] Updated StaffSelect to re-export from UserSelect
- [x] Updated PlanningTab to use Users instead of Staff
- [x] Updated PlanningTaskDialog to use Users
- [x] Added deprecation notices to Staff model export
- [x] Added deprecation notices to StaffRepository export
- [x] Deprecated StaffScreen (no longer accessible)
- [x] Removed Staff nav item from sidebar
- [x] Staff route now redirects to Settings

**Step 5: Safety Checks ✅ COMPLETE**
- [x] Build compiles successfully
- [x] No TypeScript errors
- [x] Linter passes
- [x] Backward compatibility maintained via deprecation

**Files Modified:**
- `src/v4/components/UserSelect.tsx` — NEW (replaces StaffSelect logic)
- `src/v4/components/StaffSelect.tsx` — Re-exports from UserSelect (deprecated)
- `src/v4/components/PlanningTab.tsx` — Uses User instead of StaffMember
- `src/v4/components/PlanningTaskDialog.tsx` — Uses User instead of StaffMember
- `src/v4/screens/V4App.tsx` — Removed Staff nav, redirects /staff to /settings
- `src/domain/models/staff.ts` — Added deprecation notice
- `src/domain/models/index.ts` — Added deprecation comment
- `src/data/repositories/StaffRepository.ts` — Added deprecation notice
- `src/data/repositories/index.ts` — Added deprecation comment
- `src/v4/screens/StaffScreen.tsx` — Added deprecation notice

**Key Changes:**
- StaffSelect → UserSelect (loads from AuthService.getAllUsers())
- StaffMember.label → User.department (for role hints)
- Staff nav item hidden from all roles
- /staff route redirects to /settings
- All deprecated files maintained for backward compatibility

## Completed (v322)

### Minimal Route Guards v1 (Sensitive Screens Only) ✅ COMPLETE
Implemented role-based route guards for sensitive screens:

**Route Guards Added:**
- [x] **Staff screen** — ADMIN only
- [x] **Settings screen** — ADMIN only
- [x] **Library screen** — ADMIN and OFFICE only
- [x] **WIN Register** — ADMIN and OFFICE only
- [x] **Resource Planner** — ADMIN and OFFICE only
- [x] **Project Planner** — ADMIN and OFFICE only
- [x] **Projects list** — ADMIN, OFFICE, SALES only (PRODUCTION blocked)
- [x] **Clients** — ADMIN, OFFICE, SALES only (PRODUCTION blocked)

**NoAccessScreen Enhanced:**
- [x] Role-aware navigation button
- [x] PRODUCTION → "Go to Portfolio" (redirects to Shopfloor Board)
- [x] Other roles → "Go to Dashboard"

**Production Role Behavior:**
- [x] Dashboard auto-redirects to Shopfloor Board (their home screen)
- [x] Direct URL access to /library, /settings, /staff blocked
- [x] Direct URL access to /projects, /clients blocked

**Files Modified:**
- `src/v4/screens/V4App.tsx` — Route guards and NoAccessScreen enhancement

**Acceptance Criteria Met:**
- ✅ PRODUCTION pasting /library, /settings, /staff cannot access content
- ✅ SALES pasting /library, /settings, /staff cannot access content
- ✅ ADMIN can access everything
- ✅ OFFICE can access Library but not Staff/Settings
- ✅ No new abstraction layer introduced
- ✅ Guards are local to routing layer

## Completed (v321)

### Minimal Visibility Enforcement v1 (Roles + Nav Hiding) ✅ COMPLETE
Implemented role-based sidebar visibility as per v320 plan:

**1. UserRole updated (4 roles):**
- [x] Changed `UserRole` type to: `'ADMIN' | 'OFFICE' | 'SALES' | 'PRODUCTION'`
- [x] Removed `MANAGER` and `VIEWER` roles
- [x] Updated `ROLE_HIERARCHY`, `ROLE_LABELS`, `ROLE_DESCRIPTIONS`
- [x] Updated `ROLE_PERMISSIONS` matrix

**2. Demo users updated:**
- [x] Admin → `admin@eagleboats.nl` (ADMIN)
- [x] Office → `office@eagleboats.nl` (OFFICE) — was Manager
- [x] Sales → `sales@eagleboats.nl` (SALES)
- [x] Production → `production@eagleboats.nl` (PRODUCTION)
- [x] Removed Viewer demo account

**3. Nav visibility matrix implemented (V4App.tsx):**
- [x] Added `NAV_VISIBILITY` matrix by role
- [x] Added `isNavVisible()` helper function
- [x] Sidebar items are now HIDDEN (not disabled) based on role
- [x] PRODUCTION sees only: Shopfloor Board, Production, Shop Floor Orders, Timesheets
- [x] SALES sees only: Dashboard, Projects (read-only), Clients
- [x] OFFICE sees everything except Staff and Settings
- [x] ADMIN sees all items
- [x] Added governance comment: "Visibility only. Real enforcement may add route guards later."

**4. LoginScreen updated:**
- [x] Updated demo accounts to show 4 roles
- [x] Changed Manager button to Office

**5. SettingsScreen updated:**
- [x] Updated roles array for user creation/editing
- [x] Changed default new user role to OFFICE
- [x] Updated role badge styling for OFFICE

**Files Modified:**
- `src/domain/models/user.ts` - Role enum and permissions
- `src/domain/services/AuthService.ts` - Demo users
- `src/v4/screens/V4App.tsx` - Nav visibility matrix
- `src/v4/screens/LoginScreen.tsx` - Demo account buttons
- `src/v4/screens/SettingsScreen.tsx` - User management forms

**Acceptance Criteria Met:**
- ✅ Logging in as Production shows reduced sidebar (Portfolio screens only)
- ✅ Other roles see their expected items per plan
- ✅ No route/URL blocking added (visibility only)
- ✅ No new permission abstraction layer created
- ✅ Changes minimal and localized

## Completed (v320)

### Visibility & Permissions Plan (PLANNING ONLY) ✅ COMPLETE
Created planning artifact for future implementation:
- **Document:** `.same/VISIBILITY_PERMISSIONS_PLAN.md`
- **Status:** Planning only — NOT implemented

**Deliverables:**
1. **4 Roles defined:** Admin, Office, Production, Sales
2. **Screen visibility matrix:** All screens + project tabs mapped to roles
3. **Production intent lock:** 10 allowed actions, 12 restricted areas
4. **Minimal enforcement strategy:** 4-layer approach (nav hiding, route guards, component guards, service checks)
5. **Out of scope list:** 10 items explicitly excluded

**Key Decisions:**
- Roles are flat (no hierarchy)
- Production = Portfolio-only navigation
- Sales = Read-only projects + quote editing
- Office = Full project access
- Admin = Full system access
- AI gating remains separate (aiEnabled flag)

**No implementation performed** — This is a planning artifact only.

## Completed (v318)

### Manual Regression Test Checklist ✅ COMPLETE
Created comprehensive manual test checklist for v4 stabilisation:
- **Document:** `.same/MANUAL_REGRESSION_TEST_CHECKLIST.md`
- **Estimated Time:** ~60 minutes
- **Sections:**
  - A) Smoke Tests (10-15 min) — 19 steps for boot + nav verification
  - B) Feature Regression Tests — 9 areas with preconditions, steps, expected results, edge cases
  - C) Invariants Checklist — 15 quick sanity checks for future regressions
- **No new features proposed**
- **No automation or test framework**

### Shop Floor Order List Tightening (PATCH TASK) ✅ COMPLETE
Hardened intent and added anti-ERP guardrails to prevent scope drift:

**1. Audit Logging — Minimal & Invisible ✅**
- [x] Added governance comment: "Audit log is internal only; no operational or reporting meaning"
- [x] Confirmed audit records are WRITE-ONLY (no UI exposure)
- [x] No reports, history panels, analytics, or retention logic

**2. supplier & priority Fields — Explicitly Inert ✅**
- [x] Added governance comments in order-item.ts model
- [x] Removed priority color coding (red/amber) from ShopFloorOrdersTab
- [x] Removed priority color coding (red/amber) from ShopFloorOrdersScreen
- [x] All priority badges now use neutral slate styling
- [x] No auto-sorting by priority
- [x] No supplier suggestions or master data

**3. Status Transitions — Explicit Only ✅**
- [x] Added governance comments to OrderItemService methods
- [x] Documented allowed transitions in service header
- [x] Confirmed: NOT_ORDERED → ORDERED (explicit)
- [x] Confirmed: ORDERED → NOT_ORDERED (manual revert)
- [x] Confirmed: ORDERED → RECEIVED (explicit)
- [x] Confirmed: RECEIVED is terminal
- [x] Confirmed: RECEIVED items cannot be deleted

**4. Sidebar / Navigation Intent Lock ✅**
- [x] Added governance comment in V4App.tsx near Shop Floor Orders nav item
- [x] Documents: operational production view only
- [x] Documents: must NOT expand into planning or purchasing dashboards

**Files Modified:**
- `src/domain/models/order-item.ts` - Added governance header and inert field comments
- `src/domain/services/OrderItemService.ts` - Added audit/transition governance comments
- `src/v4/screens/V4App.tsx` - Added navigation intent lock comment
- `src/v4/components/ShopFloorOrdersTab.tsx` - Added governance header, removed priority colors
- `src/v4/screens/ShopFloorOrdersScreen.tsx` - Added governance header, removed priority colors

**Acceptance Criteria Met:**
- ✅ No user-visible behavior changes (except neutral priority badges)
- ✅ No new UI elements introduced
- ✅ Code clearly documents intent and constraints
- ✅ Feature remains fully manual, explicit, and operational only

## Completed (v317)

### Improvement 4: Shop Floor Order List ✅ COMPLETE
Implemented manual operational purchasing outside BOM:

**Data Model: ✅ COMPLETE**
- [x] Create `OrderItem` entity in `/src/domain/models/order-item.ts`
- [x] Fields: id, createdAt, createdByUserId, projectId?, description, articleId?, quantity?, unit?, status, orderedAt?, orderedByUserId?, receivedAt?, receivedByUserId?, note?, supplier?, priority?
- [x] Status enum: `NOT_ORDERED` | `ORDERED` | `RECEIVED`
- [x] Create `OrderItemRepository` with CRUD and filtering
- [x] Create `OrderItemService` with business logic and audit logging

**UI Components: ✅ COMPLETE**
- [x] Create `ShopFloorOrdersTab` component for project and portfolio views
- [x] Quick add form with description (primary), quantity, unit, supplier, priority, notes
- [x] Status summary cards (Not Ordered, Ordered, Received)
- [x] Order item rows with status badges and action buttons
- [x] Status transition buttons: "Mark Ordered", "Mark Received", "Revert"
- [x] Delete option for NOT_ORDERED items only
- [x] Edit dialog for updating item details
- [x] Search and filter capabilities

**Portfolio-Level View: ✅ COMPLETE**
- [x] Create `ShopFloorOrdersScreen` for all shop floor orders
- [x] Status summary cards with counts and clickable filters
- [x] Quick Add for general orders
- [x] Tabs: All Orders / General / By Project
- [x] Project filter dropdown in "By Project" tab
- [x] Navigation link from order to project detail

**Project-Level View: ✅ COMPLETE**
- [x] Add "Orders" tab to `ProjectDetailScreen`
- [x] `ShopFloorOrdersTab` integrated with project ID
- [x] Compact mode for project context

**Navigation: ✅ COMPLETE**
- [x] Add "Shop Floor Orders" to V4App sidebar (Portfolio section)
- [x] Route: `/shop-floor-orders`
- [x] Screen type registered in navigation

**Acceptance Criteria: ✅ COMPLETE**
- [x] Production user can add an item in < 10 seconds
- [x] Item can be project-linked or general
- [x] Status can be moved forward manually; check-off on receipt is explicit
- [x] No BOM is changed; no costs are computed
- [x] Works without introducing new ERP-like screens or dependencies

**Key Design Decisions:**
- Free text description is PRIMARY (no article selection required)
- Optional article reference for convenience (no pricing logic)
- Status transitions are MANUAL ONLY with timestamps + user tracking
- Items can be project-specific or general (null projectId)
- Delete only allowed for NOT_ORDERED items
- Revert from ORDERED to NOT_ORDERED supported
- No automatic purchasing, inventory, or accounting integration

## Completed (v316)

### Improvement 2: Standards Library + Apply Suggested Standards ✅ COMPLETE
Implemented internal Standards Library with explicit "Apply suggested standards from Boat Model" flow:

**Data Model: ✅ COMPLETE**
- [x] Create `Standard` entity in domain models
- [x] Create `StandardsLibraryRepository` with CRUD operations
- [x] Create `StandardsLibraryService` with seed data (20 common CE standards)
- [x] Add `suggestedStandardIds` to BoatModel interface
- [x] Create `AppliedStandardWithOrigin` type with `libraryStandardId` and `origin` fields

**UI Components: ✅ COMPLETE**
- [x] Create `StandardsLibraryTab` for Library screen (CRUD for standards)
- [x] Integrate Standards tab in `LibraryScreen`
- [x] Update `BoatModelDialog` with suggested standards selection (collapsible section with multi-select)
- [x] Update `AppliedStandardsSection` with:
  - "Add from Library" action (picker dialog with search)
  - "Apply suggested from Boat Model" flow with preview dialog
  - Origin badges (Library/Model) on applied standards
  - Model suggestions banner when unapplied suggestions exist

**Acceptance Criteria: ✅ COMPLETE**
- [x] Creating a new project no longer requires re-typing standards
- [x] Applying suggested standards is always explicit and previewed
- [x] No background updates occur if Boat Model suggestions change later
- [x] Project remains fully editable and self-contained after applying
- [x] Standards origin (library/manual/model-suggested) is trackable

**Key Design Decisions:**
- Standards Library is internal (manually maintained, no external sync)
- Each standard has sourceNote for provenance visibility
- Boat Model suggestions are init-only (suggestions copied at apply-time)
- Project can mix library standards, model suggestions, and manual entries
- Origin tracked with `AppliedStandardOrigin` enum: LIBRARY | MODEL_SUGGESTED | MANUAL

## Completed (v315)

### AI Governance Tightening (PATCH TASK) ✅ COMPLETE
Brought AI implementation fully in line with "explicit assignment only" and prevented scope creep:

**1. aiEnabled defaults to false for ALL users:**
- [x] Admin user explicitly has `aiEnabled: false`
- [x] All demo users (Manager, Sales, Production, Viewer) explicitly have `aiEnabled: false`
- [x] Added governance comments explaining AI requires explicit admin action to enable

**2. Scope restriction (text-only):**
- [x] AI scopes restricted to: `owners-manual-section`, `compliance-text-snippet`
- [x] Removed AI suggestion buttons from vessel identity fields (intendedUse, specialConditions)
- [x] Added governance comments in ComplianceInputsSection explaining AI is NOT for spec fields
- [x] Updated AISuggestionService with strict scope documentation

**3. Removed persistent aiAssisted flag:**
- [x] Removed `aiAssisted` field from ManualBlock interface
- [x] Removed aiAssisted display badges from OwnerManualBlocksEditor
- [x] Removed aiAssisted prop from OwnerManualBlocksEditorProps
- [x] Removed AI-Assisted Draft Banner from OwnerManualBlocksEditor
- [x] Removed AI-Assisted stats card from OwnerManualSection
- [x] Accepted AI text becomes normal user-edited content (no metadata)

**4. Constraints intact:**
- [x] Suggestion-only (no auto-insert)
- [x] Explicit Accept/Dismiss required
- [x] No workflow/status coupling
- [x] No background sync

**Acceptance Criteria Met:**
- ✅ Newly created user never has AI enabled unless explicitly toggled by admin
- ✅ AI suggestions available only on text sections (Owner's Manual blocks)
- ✅ No AI metadata becomes a second "truth layer" in domain model

## Completed (v313)

### Improvement 3.5 Part B: Scoped AI Suggest Buttons with User Gating ✅ COMPLETE
Implemented per-section AI suggestion buttons with user-level gating:
- [x] Added `aiEnabled` boolean flag to User model
- [x] Updated auth context with `canUseAI()` helper method
- [x] Created `AISuggestionService` with mock content generation
- [x] Created `AISuggestionButton` component with dialog-based preview
- [x] Created `AISuggestionInline` component for inline previews
- [x] Created `AIEnabledGuard` component for conditional rendering
- [x] Integrated AI Suggest button in Owner's Manual Blocks Editor
- [x] Integrated AI Suggest buttons in Vessel Identity dialog (intendedUse, specialConditions)
- [x] Admin and Manager demo users have `aiEnabled: true` by default
- [x] AI suggestions are clearly scoped to single sections
- [x] User must explicitly Accept or Dismiss - no auto-insertion
- [x] AI does not affect compliance status, costs, or workflow

**Core Principles Maintained:**
- AI is suggestion-only, never authoritative
- AI output is never auto-inserted
- Users without aiEnabled never see AI UI elements
- Accepted AI text becomes normal user-edited text
- No AI influence on system behavior

**UI Components:**
- `AISuggestionButton`: Small "Suggest" button with sparkle icon, opens dialog
- `AISuggestionInline`: Inline preview variant (alternative)
- `AIEnabledGuard`: Guard component for AI-related sections

**Service:**
- `AISuggestionService`: Mock implementation with template-based suggestions
- Supports scopes: owner-manual-block, vessel-identity-field, compliance-declaration
- Project context passed for relevant suggestions

## Completed (v311)

### Improvement 3: Article Supplier Cost with BOM Override Badges ✅ COMPLETE
Implemented supplier cost defaults in Article library with BOM cost source tracking:
- [x] Added `supplierCostExclVat` field to LibraryArticle model
- [x] Added `supplierCostSourceNote` field to LibraryArticle model (optional)
- [x] Added `costSource` field to BOMItem: 'LIBRARY' | 'ESTIMATED' | 'OVERRIDE'
- [x] Updated ArticleDialog with supplier cost input for create and edit modes
- [x] Updated BOMService to use supplier cost from Article when available
- [x] Updated BOM UI with cost source badges (Library/Estimated/Override)
- [x] Added Supplier Cost column in Library articles table
- [x] Updated CSV export to include cost source information
- [x] Existing BOM lines NOT affected when library changes (no sync)

**Cost Resolution Rules:**
1. If Article.supplierCostExclVat is present → use it, source = "LIBRARY"
2. Else if ArticleVersion.costPrice is present → use it, source = "LIBRARY"
3. Else → estimate from sell price, source = "ESTIMATED"
4. If user edits BOM cost manually → source = "OVERRIDE" (future enhancement)

## Completed (v309)

### Improvement 3.5 Part A: Checklist → Dossier UX ✅ COMPLETE
Implemented one-click navigation from checklist items to dossier locations with evidence counts:
- [x] Added `getChecklistEvidenceCount()` helper function
- [x] Added `hasChecklistDossierLink()` helper function
- [x] Updated ChecklistItemsDialog in EvidenceFirstPanel with:
  - "Open Dossier Location" button (only shown when dossierSectionId + dossierSubheadingId exist)
  - Evidence count hint per checklist item ("Evidence: N files")
  - "No dossier link" indicator when mapping is missing
- [x] Created reusable `ChecklistEvidenceHint` component in SourceHint.tsx
- [x] Created `EvidenceCountBadge` component for consistent file count display
- [x] Deep link navigation to exact dossier subheading with scroll and highlight
- [x] Checklist status remains fully manual (PASSED/FAILED/N/A unaffected by file presence)
- [x] No new data models introduced

## Completed (v308)

### Improvement 1: Vessel Identity Init from Boat Model ✅ COMPLETE
Implemented one-time explicit copy of BoatModel specs into Project.vesselIdentity:
- [x] Added `VesselIdentityInit` interface to track init metadata
- [x] Extended `VesselIdentity` with `initFromModel` field
- [x] Added `ProjectService.initializeVesselIdentityFromBoatModel()` service function
- [x] Added "Initialize from Boat Model" button in VesselIdentityCard
- [x] Button only enabled when project has Boat Model selected
- [x] Added confirmation dialog for re-initialization (prevents accidental overwrite)
- [x] Added source hints per field: "Model" / "Edited" / "Project"
- [x] Added initialization metadata display: "Initialized from {Model} on {date}"
- [x] Project-specific fields (WIN, Year, Intended Use) preserved on re-init
- [x] All fields remain editable after initialization
- [x] No background sync - explicit user action only

## Completed (v307)

### Integrated Refinement Design Document ✅ COMPLETE (REVISED)
Created comprehensive design document following Master Prompt requirements:
- [x] Reaffirmation of 5 locked principles
- [x] Analysis table: 6 data items with ownership and friction analysis
- [x] 5 proposed improvements with full implementation details:
  1. Vessel Identity → Initialize from Boat Model
  2. Applied Standards → Internal Library with Suggested Standards
  3. Article Supplier Cost → Optional Library Default with BOM Override
  4. Shop Floor Order List → Manual Operational Purchasing
  5. Compliance UX & AI Tooling Pack (Dossier navigation + scoped AI helpers)
- [x] Explicit list of what is NOT being built (8 items)
- [x] Deferred / Later section (Staff→User, Model Templates Import, Brochure Quote Doc)
- [x] Risks/regressions analysis (3 items)
- [x] Appendix: Shop Floor UX Boundary
- [x] Appendix: AI Usage Boundaries
- [x] Implementation priority (starts with Vessel Identity Init)

Document location: `.same/INTEGRATED_REFINEMENT.md`

## Completed (v305)

### Deep Linking to Technical Dossier Sections ✅ COMPLETE
- [x] Add URL helper functions to `information-linking.ts`
  - `buildDossierDeepLinkUrl`, `buildDossierDeepLinkParams`
  - `parseDossierDeepLinkParams`, `clearDossierDeepLinkParams`
  - `navigateToDossierSection`
  - `DossierDeepLinkParams` interface
- [x] Update `V4App.tsx` to parse query params (dossierSection, subheading, lens)
- [x] Pass `dossierDeepLink` through component chain:
  - ProjectDetailScreen -> ComplianceTab -> EvidenceFirstPanel
- [x] Implement auto-expand, scroll, and highlight in EvidenceFirstPanel
  - Expand target section on mount
  - Scroll target into view with smooth behavior
  - Subtle 3-second highlight ring (calm UI)
  - Clear deep link params from URL after navigation
- [x] Update `SourceHint.tsx` components with deep link support
  - EvidenceHint: accepts projectId, lens, navigates via deep link
  - DossierSectionHint: accepts projectId, subheadingId, lens
- [x] Register refs for sections and subheadings for scroll targeting

### Query Param Scheme
```
/projects/:id?tab=compliance&dossierSection=<section-id>&subheading=<subheading-id>&lens=<CE|ES_TRIN|LLOYDS|OTHER>
```

## Completed (v304)

### Evidence-First Compliance UI with Certification Lens Views ✅ COMPLETE
- [x] Create lens derivation helpers in information-linking.ts
  - buildSubheadingLensIndex, buildSectionLensIndex
  - getAvailableLensModes, getCertPackForLens
  - getLensModeLabel, getLensModeColor, getLensModeBgColor
- [x] Create ComplianceLensSelector component
- [x] Create EvidenceFirstPanel as PRIMARY compliance surface
- [x] Remove progress bars implying workflow completion
- [x] Technical Dossier always visible, certification as overlay
- [x] Lens selector changes rendering, not data
- [x] Simplified ComplianceTab (removed separate CertificationPacks panel)
- [x] Write rationale documentation (EVIDENCE_FIRST_RATIONALE.md)

### Key Architectural Decisions
- Technical Dossier = canonical evidence (PRIMARY surface)
- Certification Packs = verification lenses (contextual overlays)
- No workflow implied, no completion flow
- All lens data derived at render time
- No state duplication between dossier and certification

## Completed (v303)

### Information Linking Enhancement ✅ COMPLETE
- [x] Create helper functions for deriving source information (`/src/domain/utils/information-linking.ts`)
- [x] Compliance inputs: Show dossier section hints for each field
- [x] Technical Dossier: Show certification pack references with pass/todo/fail counts per section
- [x] Technical Dossier: Show certification pack badges on subheadings
- [x] Certification Pack checklist: Show evidence location with "Evidence: Dossier → Section → Subheading" format
- [x] Navigation: EvidenceHint component with clickable navigation to dossier
- [x] New components: SourceHint.tsx, CertPackReferences.tsx

## Completed Features (Latest: v300)

### Architecture Documentation ✅ COMPLETE
- [x] Created comprehensive architecture layout (ARCHITECTURE_LAYOUT.md)
- [x] Created models CSV (architecture-models.csv)
- [x] Created services CSV (architecture-services.csv)
- [x] Created screens/components CSV (architecture-screens.csv)
- [x] Created repositories CSV (architecture-repositories.csv)
- [x] Created enums CSV (architecture-enums.csv)
- [x] Generated consolidated Excel workbook (Navisol-Architecture.xlsx) with 6 sheets

### Production Tab Consolidation ✅ COMPLETE (v300)
- [x] Removed separate Kanban tab from project tabs
- [x] Added List/Kanban view toggle to Production tab
- [x] Simplified tab navigation with fewer top-level tabs
- [x] View toggle with task counts inline
- [x] Consolidated task management into single Production tab

### Work Instructions Library Module ✅ COMPLETE
- [x] Domain Model: `src/domain/models/work-instruction.ts`
- [x] Repository: `src/data/repositories/WorkInstructionRepository.ts`
- [x] Service: `src/domain/services/WorkInstructionService.ts`
- [x] Library Tab: `src/v4/components/WorkInstructionsTab.tsx`
- [x] Viewer: `src/v4/components/WorkInstructionViewer.tsx`
- [x] Editor: `src/v4/components/WorkInstructionEditor.tsx`
- [x] Sample data initialization (4 demo instructions)
- [x] Duplicate functionality (creates draft copy)
- [x] Link Work Instructions to production tasks via `workInstructionId` field
- [x] TaskDialog updated with work instruction selector dropdown
- [x] Display linked Work Instructions in task cards (Kanban)
- [x] Quick-view popup: `src/v4/components/WorkInstructionQuickView.tsx`
- [x] Integration in `ProjectStageKanbanTab.tsx` (project-level Kanban)
- [x] Integration in `ProductionScreen.tsx` (portfolio-level Kanban)

### Production Kanban (v291-v294) ✅ COMPLETE
- [x] Project-level Kanban tab in ProjectDetailScreen
- [x] Portfolio-level Production screen
- [x] Drag-and-drop between stages
- [x] In-column task reordering with stageSortOrder
- [x] Mini task cards with status, assignee, dates

### Shopfloor Board ✅ COMPLETE
- [x] Planning tasks execution view
- [x] Date range filtering
- [x] Assignee and project filters
- [x] Undo support for status changes

### Technical Dossier & Compliance ✅ COMPLETE
- [x] 10-section Technical Dossier structure
- [x] Subheadings per section with stable IDs
- [x] Checklist items linked to dossier subheadings
- [x] CE compliance scaffold with auto-evidence counting
- [x] WIN terminology standardization

### Template System ✅ COMPLETE
- [x] Quote template with placeholders
- [x] Equipment List template
- [x] Owner's Manual modular blocks
- [x] Boat Model specifications for templates

## Architecture Notes

### Navisol v4 Principles
- Single write path via services (no ad-hoc repository writes)
- Explicit user-driven actions only (no background sync)
- Calm UI with clear states
- TypeScript strict compliance
- Stable IDs for all entities

### Work Instructions Architecture
- Library-level entities (not project-scoped)
- Categorized by ProductionStageCode
- Scope: 'general' or 'modelSpecific'
- Markdown content with attachments
- Comments are append-only
- Tasks reference instructions via workInstructionId

## Potential Next Steps
1. Filter tasks by linked work instruction
2. PDF export of work instructions
3. Work instruction version history
4. Bulk assign work instructions to tasks
5. Work instruction templates per boat model
6. Analytics/reporting on instruction usage

## Completed

### Staff → User Unification ✅ COMPLETE
Consolidated Staff concept into User model.

**Step 1: Inventory ✅ COMPLETE**
- [x] Analyzed Staff model fields
- [x] Analyzed Staff usage locations
- [x] Compared with User model
- [x] Created inventory document: `.same/STAFF_USER_INVENTORY.md`

**Step 2: Target Model ✅ COMPLETE**
- [x] User model unchanged (department absorbs Staff.label)
- [x] No new fields required

**Step 3: Data Migration Plan ✅ COMPLETE**
- [x] Migration rules defined
- [x] Dry-run format specified

**Step 4: Implementation ✅ COMPLETE**
- [x] Created UserSelect component (replaces StaffSelect)
- [x] Updated StaffSelect to re-export from UserSelect
- [x] Updated PlanningTab to use Users instead of Staff
- [x] Updated PlanningTaskDialog to use Users
- [x] Added deprecation notices to Staff model export
- [x] Added deprecation notices to StaffRepository export
- [x] Deprecated StaffScreen (no longer accessible)
- [x] Removed Staff nav item from sidebar
- [x] Staff route now redirects to Settings

**Step 5: Safety Checks ✅ COMPLETE**
- [x] Build compiles successfully
- [x] No TypeScript errors
- [x] Linter passes
- [x] Backward compatibility maintained via deprecation

**Files Modified:**
- `src/v4/components/UserSelect.tsx` — NEW (replaces StaffSelect logic)
- `src/v4/components/StaffSelect.tsx` — Re-exports from UserSelect (deprecated)
- `src/v4/components/PlanningTab.tsx` — Uses User instead of StaffMember
- `src/v4/components/PlanningTaskDialog.tsx` — Uses User instead of StaffMember
- `src/v4/screens/V4App.tsx` — Removed Staff nav, redirects /staff to /settings
- `src/domain/models/staff.ts` — Added deprecation notice
- `src/domain/models/index.ts` — Added deprecation comment
- `src/data/repositories/StaffRepository.ts` — Added deprecation notice
- `src/data/repositories/index.ts` — Added deprecation comment
- `src/v4/screens/StaffScreen.tsx` — Added deprecation notice

**Key Changes:**
- StaffSelect → UserSelect (loads from AuthService.getAllUsers())
- StaffMember.label → User.department (for role hints)
- Staff nav item hidden from all roles
- /staff route redirects to /settings
- All deprecated files maintained for backward compatibility

## Pending Tasks

### Improvement 4: Shop Floor Order List (Future)
- [ ] Create ShopFloorOrderItem entity
- [ ] Create ShopFloorOrderService
- [ ] Create Orders tab in Portfolio sidebar
- [ ] Implement order status workflow

### A) Extend Boat Model with Sales Content
- [x] Add salesSections, salesImages, salesSource to BoatModel interface (DONE in BoatModelService.ts)
- [x] Update BoatModelService with sales content fields in create/update (DONE)
- [x] Add Sales Content tab to BoatModelDialog.tsx
- [x] Implement CRUD UI for salesSections (add, reorder, delete)
- [x] Implement image slot management for salesImages
- [x] Add "Create Default Headings" helper button (creates empty placeholders only)

### B) Quote Deliverable - Customer Offer
- [x] Create CustomerOffer model (customer-offer.ts)
- [x] Create CustomerOfferService with block generation
- [x] Add "Generate Customer Offer" action in Quote screen
- [x] Implement block-based structure (Cover, Intro, Gallery, Equipment, Pricing, Terms)
- [x] Enable manual block editing after generation
- [x] Add HTML preview for Customer Offer
- [x] Add regeneration with confirmation (Option A: overwrite draft)
